<?php
/** Justificatif transactionnel de paiement Stripe (ne vaut pas facture fiscale). */
require_once __DIR__ . '/includes/functions.php';
if (!is_logged()) { header('Location: ' . u('/connexion')); exit; }
$u = user();
$projet_id = (int)($_GET['projet'] ?? 0);
$st = db()->prepare("SELECT p.id,p.reference,p.titre,p.entreprise_id,p.freelance_id,p.paiement_fin_livraison,
                            e.societe,e.prenom AS client_prenom,e.nom AS client_nom,
                            f.prenom AS freelance_prenom,f.nom AS freelance_nom,
                            pa.id AS paiement_id,pa.montant,pa.reference AS paiement_reference,pa.paye_le,
                            pa.stripe_application_fee,pa.stripe_account
                     FROM paiements pa JOIN projets p ON p.id=pa.projet_id
                     JOIN users e ON e.id=p.entreprise_id
                     LEFT JOIN users f ON f.id=p.freelance_id
                     WHERE pa.projet_id=? AND pa.type='projet' AND pa.statut='paye' AND pa.stripe_direct=1
                     ORDER BY pa.id DESC LIMIT 1");
$st->execute([$projet_id]);
$recu = $st->fetch();
$autorise = $recu && ((int)$recu['entreprise_id']===(int)$u['id']
    || (($u['role'] ?? '')==='admin' && peut_gerer_projet($recu)));
if (!$autorise) {
    http_response_code(404);
    flash("Aucun justificatif de paiement accessible n'a été trouvé.", 'error');
    header('Location: ' . u('projet.php?id=' . $projet_id)); exit;
}
// Seconde tentative idempotente si le courriel transactionnel a échoué à la confirmation Stripe.
email_paiement_recu($projet_id, (int)$recu['paiement_id']);
$commission = (int)round(((int)$recu['stripe_application_fee'])/100);
$total = (int)$recu['montant'];
$base = max(0, $total-$commission);
$titre = 'Justificatif de paiement';
require_once __DIR__ . '/includes/header.php';
?>
<div class="app">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
  <div class="page-head no-print">
    <div><p class="small muted mb-1"><a href="<?= e(u('projet.php?id='.$projet_id)) ?>" style="color:var(--blue)">← Retour au projet</a></p><h1>Justificatif de paiement</h1><p>Confirmation de règlement sécurisé par Stripe.</p></div>
    <button type="button" class="btn btn-primary" onclick="window.print()">Imprimer / enregistrer en PDF</button>
  </div>
  <section class="panel" style="max-width:820px;margin:0 auto">
    <div class="panel-body" style="padding:clamp(22px,5vw,52px)">
      <div class="flex-between wrap" style="gap:16px;border-bottom:1px solid var(--line);padding-bottom:18px;margin-bottom:24px">
        <div><strong style="font-size:1.35rem">Missiona</strong><p class="small muted mb-0">Justificatif de paiement électronique</p></div>
        <span class="badge badge-green">Paiement confirmé</span>
      </div>
      <h2 style="margin-bottom:8px">Règlement reçu</h2>
      <p class="muted">Ce document confirme le paiement traité par Missiona via Stripe. Il ne constitue pas une facture fiscale.</p>
      <div class="recap mt-3">
        <div class="recap-row"><span>Référence du projet</span><strong><?= e(reference_projet_courte($recu['reference'], $projet_id)) ?></strong></div>
        <div class="recap-row"><span>Projet</span><strong><?= e($recu['titre']) ?></strong></div>
        <div class="recap-row"><span>Payeur</span><strong><?= e($recu['societe'] ?: trim($recu['client_prenom'].' '.$recu['client_nom'])) ?></strong></div>
        <div class="recap-row"><span>Expert</span><strong><?= e(trim($recu['freelance_prenom'].' '.$recu['freelance_nom'])) ?></strong></div>
        <div class="recap-row"><span>Date de confirmation</span><strong><?= e($recu['paye_le'] ? date('d/m/Y à H:i', strtotime($recu['paye_le'])) : '—') ?></strong></div>
        <div class="recap-row"><span>Référence de paiement</span><strong><?= e($recu['paiement_reference'] ?: ('PAIEMENT-'.$recu['paiement_id'])) ?></strong></div>
      </div>
      <div class="recap mt-3">
        <div class="recap-row"><span>Rémunération de l'expert</span><strong><?= euros($base) ?></strong></div>
        <div class="recap-row"><span>Commission Missiona incluse</span><strong><?= euros($commission) ?></strong></div>
        <div class="recap-row" style="font-size:1.08rem"><span>Total payé</span><strong><?= euros($total) ?></strong></div>
      </div>
      <p class="small muted mt-3">À conserver pour votre suivi comptable. Ce justificatif de paiement ne remplace ni une facture de prestation établie par l'expert, ni une facture fiscale de Missiona lorsque celle-ci est requise.</p>
    </div>
  </section>
</main>
</div>
<style>@media print{.no-print,.sidebar,.topbar{display:none!important}.app,.main{display:block!important;margin:0!important;padding:0!important}.panel{box-shadow:none!important;border:0!important}.panel-body{padding:0!important}body{background:#fff!important}}</style>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
