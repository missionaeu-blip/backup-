<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';

function live_json_response(int $status, array $payload): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private, max-age=0');
    header('X-Content-Type-Options: nosniff');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (!is_logged()) {
    live_json_response(401, ['ok' => false, 'error' => 'session']);
}

try {
    $u = user();
    if (!$u) live_json_response(401, ['ok' => false, 'error' => 'session']);
    $uid = (int)$u['id'];
    $role = (string)$u['role'];

    if ($role === 'admin') {
        $projectRows = db()->query("SELECT id, titre, categorie, description, competences, budget_min, budget_max, delai, date_limite, statut, avancement, freelance_id, montant_final, created_at FROM projets ORDER BY id ASC")->fetchAll();
    } elseif (est_client($role)) {
        $st = db()->prepare("SELECT id, titre, categorie, description, competences, budget_min, budget_max, delai, date_limite, statut, avancement, freelance_id, montant_final, created_at FROM projets WHERE entreprise_id=? ORDER BY id ASC");
        $st->execute([$uid]);
        $projectRows = $st->fetchAll();
    } elseif ($role === 'freelance') {
        $st = db()->prepare("SELECT id, titre, categorie, description, competences, budget_min, budget_max, delai, date_limite, statut, avancement, freelance_id, montant_final, created_at FROM projets WHERE freelance_id=? ORDER BY id ASC");
        $st->execute([$uid]);
        $projectRows = $st->fetchAll();
    } else {
        $projectRows = [];
    }

    $projectIds = array_map(static fn($p) => (int)$p['id'], $projectRows);
    $projectState = [];
    $projects = [];
    foreach ($projectRows as $p) {
        $id = (int)$p['id'];
        $status = (string)$p['statut'];
        $progress = max(0, min(100, (int)$p['avancement']));
        $projectState[] = [
            $id, (string)$p['titre'], (string)$p['categorie'], (string)$p['description'],
            (string)$p['competences'], (int)$p['budget_min'], (int)$p['budget_max'],
            (string)$p['delai'], (string)$p['date_limite'], $status, $progress,
            (int)($p['freelance_id'] ?? 0), (int)($p['montant_final'] ?? 0),
            (string)$p['created_at'],
        ];
        $projects[] = [
            'id' => $id,
            'statut' => $status,
            'label' => statut_label($status),
            'classe' => statut_classe($status),
            'avancement' => $progress,
        ];
    }

    /* Révision de données visibles : elle permet de détecter changements de
       projet, livrable, demande ou paiement sans exposer les données privées. */
    $related = [];
    $tables = [
        'fichiers' => ['id', 'projet_id', 'nom', 'created_at'],
        'paiements' => ['id', 'projet_id', 'type', 'statut', 'paye_le'],
        'demandes' => ['id', 'projet_id', 'statut', 'traite_le'],
        'factures' => ['id', 'projet_id', 'statut'],
        'evaluations' => ['id', 'projet_id', 'auteur_id', 'cible_id', 'note', 'commentaire', 'created_at'],
    ];
    foreach ($tables as $table => $columns) {
        $related[$table] = [];
        if (!$projectIds) continue;
        foreach (array_chunk($projectIds, 300) as $ids) {
            $marks = implode(',', array_fill(0, count($ids), '?'));
            $select = implode(',', array_map(static fn($c) => 't.' . $c, $columns));
            try {
                $sql = "SELECT $select FROM $table t WHERE t.projet_id IN ($marks) ORDER BY t.id ASC";
                $st = db()->prepare($sql);
                $st->execute($ids);
                foreach ($st->fetchAll() as $row) $related[$table][] = array_values($row);
            } catch (Throwable $e) {
                // Une table/colonne indisponible n'empêche pas la messagerie live.
                $related[$table][] = ['indisponible'];
            }
        }
    }

    // Les retraits sont rattachés au compte freelance (pas au projet).
    $related['retraits'] = [];
    if ($role === 'admin') {
        $related['retraits'] = db()->query("SELECT id, freelance_id, montant, frais, net, devise, methode, statut, reference, note, traite_le, created_at FROM retraits ORDER BY id ASC")->fetchAll(PDO::FETCH_NUM);
    } elseif ($role === 'freelance') {
        $st = db()->prepare("SELECT id, freelance_id, montant, frais, net, devise, methode, statut, reference, note, traite_le, created_at FROM retraits WHERE freelance_id=? ORDER BY id ASC");
        $st->execute([$uid]);
        $related['retraits'] = $st->fetchAll(PDO::FETCH_NUM);
    }

    $notifications = notifications($uid, 6);
    $notifItems = [];
    $notifRevision = [];
    foreach ($notifications as $n) {
        $rawLink = trim((string)($n['lien'] ?? ''));
        $safeLink = ($rawLink === '' || $rawLink[0] === '#') ? ($rawLink ?: '#') : '/' . ltrim($rawLink, '/');
        $item = [
            'id' => (int)$n['id'],
            'texte' => (string)$n['texte'],
            'lien' => $safeLink,
            'lu' => (int)$n['lu'] === 1,
            'date' => date_fr((string)$n['created_at']),
        ];
        $notifItems[] = $item;
        $notifRevision[] = [(int)$n['id'], (int)$n['lu']];
    }
    $unreadNotifications = nb_notifs_non_lues($uid);

    $st = db()->prepare("SELECT COUNT(*) FROM messages WHERE destinataire_id=? AND lu=0");
    $st->execute([$uid]);
    $unreadMessages = (int)$st->fetchColumn();

    $unreadAdminChat = 0;
    if ($role === 'admin') {
        $st = db()->prepare("SELECT COUNT(*) FROM admin_conversation_messages m
                             JOIN admin_conversation_members cm ON cm.conversation_id=m.conversation_id
                             WHERE cm.user_id=? AND m.sender_id<>? AND m.id>cm.last_read_message_id");
        $st->execute([$uid, $uid]);
        $unreadAdminChat = (int)$st->fetchColumn();
    }

    $revision = hash('sha256', json_encode([
        $projectState,
        $related,
        $notifRevision,
        $unreadNotifications,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));

    live_json_response(200, [
        'ok' => true,
        'revision' => $revision,
        'projects' => $projects,
        'notifications' => $notifItems,
        'unread_notifications' => $unreadNotifications,
        'unread_messages' => $unreadMessages,
        'unread_admin_chat' => $unreadAdminChat,
        'server_time' => date(DATE_ATOM),
    ]);
} catch (Throwable $e) {
    error_log('[live-updates] ' . get_class($e));
    live_json_response(500, ['ok' => false, 'error' => 'diagnostic_indisponible']);
}
