<?php
require_once __DIR__ . '/includes/functions.php';
require_role('admin');

$u = user();
$pdo = db();
$uid = (int) $u['id'];

function missiona_admin_chat_json(int $status, array $payload): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private, max-age=0');
    header('X-Content-Type-Options: nosniff');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function missiona_admin_chat_is_member(PDO $pdo, int $conversationId, int $userId): bool {
    $st = $pdo->prepare('SELECT 1 FROM admin_conversation_members WHERE conversation_id=? AND user_id=? LIMIT 1');
    $st->execute([$conversationId, $userId]);
    return (bool) $st->fetchColumn();
}

function missiona_admin_chat_conversations(PDO $pdo, int $userId): array {
    $sql = "SELECT c.id, c.type, c.title, c.created_at,
                   CASE WHEN c.type='group' THEN c.title ELSE COALESCE(
                     (SELECT COALESCE(NULLIF(TRIM(COALESCE(u.prenom,'') || ' ' || COALESCE(u.nom,'')),''),u.email)
                      FROM admin_conversation_members mm
                      JOIN users u ON u.id=mm.user_id
                      WHERE mm.conversation_id=c.id AND mm.user_id<>?
                      LIMIT 1), 'Administrateur') END AS label,
                   (SELECT m.contenu FROM admin_conversation_messages m
                    WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS preview,
                   COALESCE((SELECT m.created_at FROM admin_conversation_messages m
                    WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1), c.created_at) AS last_at,
                   (SELECT COUNT(*) FROM admin_conversation_messages m
                    WHERE m.conversation_id=c.id AND m.sender_id<>?
                      AND m.id>mine.last_read_message_id) AS unread
            FROM admin_conversations c
            JOIN admin_conversation_members mine ON mine.conversation_id=c.id
            WHERE mine.user_id=?
            ORDER BY last_at DESC, c.id DESC";
    $st = $pdo->prepare($sql);
    $st->execute([$userId, $userId, $userId]);
    return $st->fetchAll();
}

function missiona_admin_chat_message_row(array $row, int $currentUserId): array {
    $name = trim((string)($row['prenom'] ?? '') . ' ' . (string)($row['nom'] ?? ''));
    return [
        'id' => (int)$row['id'],
        'sender_id' => (int)$row['sender_id'],
        'sender_name' => $name !== '' ? $name : 'Administrateur',
        'mine' => (int)$row['sender_id'] === $currentUserId,
        'text' => (string)$row['contenu'],
        'time' => date('d/m/Y H:i', strtotime((string)$row['created_at'])),
    ];
}

$admins = $pdo->query("SELECT id, email, nom, prenom FROM users
                       WHERE role='admin' AND COALESCE(actif,1)=1
                       ORDER BY prenom COLLATE NOCASE, nom COLLATE NOCASE, id")->fetchAll();

// Un seul salon collectif, ajouté automatiquement à tous les administrateurs actifs.
$st = $pdo->prepare("INSERT OR IGNORE INTO admin_conversations (type,pair_key,title,created_by)
                     VALUES ('group','group:main','Équipe admin',?)");
$st->execute([$uid]);
$st = $pdo->prepare("SELECT id FROM admin_conversations WHERE pair_key='group:main' LIMIT 1");
$st->execute();
$groupId = (int)$st->fetchColumn();
$memberSt = $pdo->prepare('INSERT OR IGNORE INTO admin_conversation_members (conversation_id,user_id) VALUES (?,?)');
foreach ($admins as $admin) {
    $memberSt->execute([$groupId, (int)$admin['id']]);
}

// Création d'un fil privé : seules deux sessions ayant le rôle admin peuvent en faire partie.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_direct') {
    csrf_check();
    $targetId = (int)($_POST['admin_id'] ?? 0);
    $targetSt = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='admin' AND COALESCE(actif,1)=1 LIMIT 1");
    $targetSt->execute([$targetId]);
    if ($targetId <= 0 || $targetId === $uid || !$targetSt->fetchColumn()) {
        flash('Choisis un autre compte administrateur actif.', 'error');
        header('Location: ' . u('/admin-chat'));
        exit;
    }
    $low = min($uid, $targetId);
    $high = max($uid, $targetId);
    $pairKey = 'direct:' . $low . ':' . $high;
    try {
        $pdo->beginTransaction();
        $st = $pdo->prepare("INSERT OR IGNORE INTO admin_conversations (type,pair_key,title,created_by)
                             VALUES ('direct',?,'',?)");
        $st->execute([$pairKey, $uid]);
        $st = $pdo->prepare('SELECT id FROM admin_conversations WHERE pair_key=? LIMIT 1');
        $st->execute([$pairKey]);
        $conversationId = (int)$st->fetchColumn();
        $memberSt = $pdo->prepare('INSERT OR IGNORE INTO admin_conversation_members (conversation_id,user_id) VALUES (?,?)');
        $memberSt->execute([$conversationId, $uid]);
        $memberSt->execute([$conversationId, $targetId]);
        $pdo->commit();
        header('Location: ' . u('/admin-chat?c=' . $conversationId));
        exit;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[admin-chat] création conversation: ' . get_class($e));
        flash('La conversation privée n’a pas pu être ouverte.', 'error');
        header('Location: ' . u('/admin-chat'));
        exit;
    }
}

// Envoi asynchrone d'un message. Le serveur revalide la qualité admin et l'appartenance au fil.
if (($_GET['ajax'] ?? '') === 'send') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') missiona_admin_chat_json(405, ['ok'=>false,'error'=>'method']);
    csrf_check();
    $conversationId = (int)($_POST['c'] ?? 0);
    if ($conversationId <= 0 || !missiona_admin_chat_is_member($pdo, $conversationId, $uid)) {
        missiona_admin_chat_json(403, ['ok'=>false,'error'=>'conversation']);
    }
    $text = trim((string)($_POST['contenu'] ?? ''));
    if ($text === '' || strlen($text) > 8000) {
        missiona_admin_chat_json(422, ['ok'=>false,'error'=>'text']);
    }
    $st = $pdo->prepare('INSERT INTO admin_conversation_messages (conversation_id,sender_id,contenu) VALUES (?,?,?)');
    $st->execute([$conversationId, $uid, $text]);
    $messageId = (int)$pdo->lastInsertId();
    $st = $pdo->prepare('UPDATE admin_conversation_members SET last_read_message_id=MAX(last_read_message_id,?) WHERE conversation_id=? AND user_id=?');
    $st->execute([$messageId, $conversationId, $uid]);
    $st = $pdo->prepare('SELECT m.id,m.sender_id,m.contenu,m.created_at,u.prenom,u.nom
                         FROM admin_conversation_messages m LEFT JOIN users u ON u.id=m.sender_id
                         WHERE m.id=? AND m.conversation_id=?');
    $st->execute([$messageId, $conversationId]);
    $row = $st->fetch();
    missiona_admin_chat_json(201, ['ok'=>true,'message'=>missiona_admin_chat_message_row($row ?: [], $uid)]);
}

// Poll des nouveaux messages et des résumés (nouveaux fils, aperçus, non lus).
if (($_GET['ajax'] ?? '') === 'poll') {
    $conversationId = (int)($_GET['c'] ?? 0);
    $after = max(0, (int)($_GET['after'] ?? 0));
    if ($conversationId <= 0 || !missiona_admin_chat_is_member($pdo, $conversationId, $uid)) {
        missiona_admin_chat_json(403, ['ok'=>false,'error'=>'conversation']);
    }
    $st = $pdo->prepare('SELECT m.id,m.sender_id,m.contenu,m.created_at,u.prenom,u.nom
                         FROM admin_conversation_messages m LEFT JOIN users u ON u.id=m.sender_id
                         WHERE m.conversation_id=? AND m.id>? ORDER BY m.id ASC LIMIT 100');
    $st->execute([$conversationId, $after]);
    $rows = $st->fetchAll();
    $messages = array_map(static fn($row) => missiona_admin_chat_message_row($row, $uid), $rows);
    if ($rows) {
        $lastSeen = max(array_map(static fn($row) => (int)$row['id'], $rows));
        $st = $pdo->prepare('UPDATE admin_conversation_members SET last_read_message_id=MAX(last_read_message_id,?) WHERE conversation_id=? AND user_id=?');
        $st->execute([$lastSeen, $conversationId, $uid]);
    }
    missiona_admin_chat_json(200, [
        'ok'=>true,
        'messages'=>$messages,
        'conversations'=>missiona_admin_chat_conversations($pdo, $uid),
    ]);
}

$conversations = missiona_admin_chat_conversations($pdo, $uid);
$requestedId = (int)($_GET['c'] ?? $groupId);
$selected = null;
foreach ($conversations as $conversation) {
    if ((int)$conversation['id'] === $requestedId) { $selected = $conversation; break; }
}
if (!$selected) {
    foreach ($conversations as $conversation) {
        if ((int)$conversation['id'] === $groupId) { $selected = $conversation; break; }
    }
}
$selectedId = $selected ? (int)$selected['id'] : $groupId;

$st = $pdo->prepare("SELECT m.id,m.sender_id,m.contenu,m.created_at,u.prenom,u.nom
                     FROM (SELECT * FROM admin_conversation_messages
                           WHERE conversation_id=? ORDER BY id DESC LIMIT 100) m
                     LEFT JOIN users u ON u.id=m.sender_id
                     ORDER BY m.id ASC");
$st->execute([$selectedId]);
$messageRows = $st->fetchAll();
$initialMessages = array_map(static fn($row) => missiona_admin_chat_message_row($row, $uid), $messageRows);
if ($messageRows) {
    $lastSeen = max(array_map(static fn($row) => (int)$row['id'], $messageRows));
    $st = $pdo->prepare('UPDATE admin_conversation_members SET last_read_message_id=MAX(last_read_message_id,?) WHERE conversation_id=? AND user_id=?');
    $st->execute([$lastSeen, $selectedId, $uid]);
}
$lastMessageId = $initialMessages ? (int)$initialMessages[count($initialMessages)-1]['id'] : 0;
// Recalcul après marquage de lecture : le fil courant n'affiche plus de non-lus.
$conversations = missiona_admin_chat_conversations($pdo, $uid);
foreach ($conversations as $conversation) {
    if ((int)$conversation['id'] === $selectedId) { $selected = $conversation; break; }
}

$otherAdmins = array_values(array_filter($admins, static fn($admin) => (int)$admin['id'] !== $uid));
$titre = 'Discussion entre administrateurs';
$page = 'admin-chat';
header('X-Robots-Tag: noindex, nofollow, noarchive');
require_once __DIR__ . '/includes/header.php';
$flashMsg = flash();
?>
<style>
.admin-chat-layout{display:grid;grid-template-columns:minmax(230px,300px) minmax(0,1fr);gap:18px;min-height:calc(100vh - 190px)}
.admin-chat-panel{background:#fff;border:1px solid #e6eaf0;border-radius:16px;overflow:hidden;min-width:0}
.admin-chat-list{padding:10px;max-height:calc(100vh - 260px);overflow:auto}
.admin-chat-list-title{font-size:.74rem;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#768397;padding:10px 10px 7px}
.admin-chat-link{display:flex;gap:10px;align-items:center;text-decoration:none;color:#182230;padding:11px 10px;border-radius:12px;margin-bottom:4px}
.admin-chat-link:hover,.admin-chat-link.active{background:#f0f5ff}
.admin-chat-avatar{width:38px;height:38px;flex:0 0 38px;border-radius:13px;background:#e9efff;color:#315bba;display:grid;place-items:center;font-weight:800}
.admin-chat-link-main{min-width:0;flex:1}
.admin-chat-link-name{display:flex;gap:8px;align-items:center;justify-content:space-between;font-weight:750;font-size:.9rem}
.admin-chat-preview{display:block;color:#758196;font-size:.77rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:3px}
.admin-chat-unread{min-width:20px;height:20px;padding:0 6px;border-radius:99px;background:#d92d20;color:#fff;display:grid;place-items:center;font-size:.7rem;font-weight:800}
.admin-chat-main{display:flex;flex-direction:column;min-height:580px}
.admin-chat-head{padding:18px 22px;border-bottom:1px solid #e8edf2;display:flex;justify-content:space-between;align-items:center;gap:12px}
.admin-chat-head h1{font-size:1.08rem;margin:0;color:#182230}
.admin-chat-head p{font-size:.82rem;color:#758196;margin:5px 0 0}
.admin-chat-messages{padding:20px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:12px;max-height:calc(100vh - 360px);min-height:300px;scroll-behavior:smooth}
.admin-chat-msg{display:block!important;flex:0 0 auto!important;flex-grow:0!important;width:fit-content!important;height:max-content!important;min-height:0!important;max-height:none!important;max-width:min(78%,680px);align-self:flex-start;background:#f1f4f8;border-radius:14px 14px 14px 4px;padding:10px 13px;color:#1d2939;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.45}
.admin-chat-msg.mine{align-self:flex-end;background:#e7efff;border-radius:14px 14px 4px 14px}
.admin-chat-sender{display:block;font-size:.7rem;font-weight:800;color:#53647b;margin-bottom:4px}
.admin-chat-time{display:block;text-align:right;font-size:.67rem;color:#7f8a9b;margin-top:5px}
.admin-chat-compose{padding:14px 16px;border-top:1px solid #e8edf2;display:flex;align-items:flex-end;gap:10px}
.admin-chat-compose textarea{resize:vertical;min-height:46px;max-height:140px;flex:1;border:1px solid #d6deea;border-radius:12px;padding:11px 12px;font:inherit}
.admin-chat-compose button{min-height:44px;white-space:nowrap}
.admin-chat-new{padding:12px;border-top:1px solid #eef1f5}
.admin-chat-new form{display:flex;gap:7px}
.admin-chat-new select{min-width:0;flex:1;border:1px solid #d6deea;border-radius:10px;padding:8px;font:inherit}
.admin-chat-empty{margin:auto;text-align:center;color:#758196;padding:30px;max-width:400px}
.admin-chat-empty strong{display:block;color:#344054;margin-bottom:6px}
@media(max-width:800px){.admin-chat-layout{grid-template-columns:1fr;min-height:0}.admin-chat-list{max-height:260px}.admin-chat-main{min-height:62vh}.admin-chat-messages{max-height:52vh;min-height:260px}.admin-chat-msg{max-width:90%}.admin-chat-head{padding:15px}}
</style>
<div class="app app-chat">
  <?php require __DIR__ . '/includes/sidebar.php'; ?>
  <main class="main main-chat">
    <div class="page-head">
      <div><h1>Discussion de l’équipe admin</h1><p>Conversations privées et salon collectif · réservé aux administrateurs</p></div>
    </div>
    <?php if ($flashMsg): ?><div class="alert alert-<?= e($flashMsg['t']) ?>" role="status"><?= e($flashMsg['m']) ?></div><?php endif; ?>
    <div class="admin-chat-layout">
      <section class="admin-chat-panel" aria-label="Conversations administrateur">
        <div class="admin-chat-list-title">Conversations</div>
        <nav class="admin-chat-list" id="adminChatList" aria-label="Fils de discussion">
          <?php foreach ($conversations as $conversation): ?>
            <a class="admin-chat-link <?= (int)$conversation['id']===$selectedId?'active':'' ?>"
               href="<?= e(u('/admin-chat?c='.(int)$conversation['id'])) ?>"
               data-conversation-id="<?= (int)$conversation['id'] ?>">
              <span class="admin-chat-avatar" aria-hidden="true"><?= $conversation['type']==='group'?'👥':'💬' ?></span>
              <span class="admin-chat-link-main">
                <span class="admin-chat-link-name"><span class="admin-chat-label"><?= e($conversation['label']) ?></span>
                  <?php if ((int)$conversation['unread']>0): ?><span class="admin-chat-unread"><?= (int)$conversation['unread']>99?'99+':(int)$conversation['unread'] ?></span><?php endif; ?>
                </span>
                <span class="admin-chat-preview"><?= e($conversation['preview'] ?: ($conversation['type']==='group'?'Salon collectif de l’équipe':'Conversation privée')) ?></span>
              </span>
            </a>
          <?php endforeach; ?>
          <?php if (!$conversations): ?><div class="admin-chat-empty">Aucune conversation disponible.</div><?php endif; ?>
        </nav>
        <?php if ($otherAdmins): ?>
        <div class="admin-chat-new">
          <form method="post" action="<?= e(u('/admin-chat')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_direct">
            <select name="admin_id" aria-label="Choisir un administrateur" required>
              <option value="">Nouveau message privé…</option>
              <?php foreach ($otherAdmins as $admin): ?>
                <option value="<?= (int)$admin['id'] ?>"><?= e(trim(($admin['prenom'] ?? '').' '.($admin['nom'] ?? '')) ?: $admin['email']) ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-ghost btn-sm">Ouvrir</button>
          </form>
        </div>
        <?php endif; ?>
      </section>

      <section class="admin-chat-panel admin-chat-main" aria-label="Fil de discussion">
        <header class="admin-chat-head">
          <div><h1><?= e($selected['label'] ?? 'Discussion admin') ?></h1>
            <p><?= ($selected['type'] ?? '')==='group' ? 'Salon partagé par les administrateurs actifs' : 'Conversation privée entre administrateurs' ?></p>
          </div>
          <span class="badge badge-gray"><?= ($selected['type'] ?? '')==='group' ? 'Salon collectif' : 'Privé' ?></span>
        </header>
        <div class="admin-chat-messages" id="chatBody" aria-live="polite" aria-relevant="additions text"
             data-conversation-id="<?= $selectedId ?>" data-last-id="<?= $lastMessageId ?>" data-type="<?= e($selected['type'] ?? 'group') ?>">
          <?php if (!$initialMessages): ?>
            <div class="admin-chat-empty" id="adminChatEmpty"><strong>La discussion commence ici.</strong>Écris ton premier message à l’équipe.</div>
          <?php else: foreach ($initialMessages as $message): ?>
            <article class="admin-chat-msg <?= $message['mine']?'mine':'' ?>" data-message-id="<?= (int)$message['id'] ?>">
              <?php if (($selected['type'] ?? '')==='group'): ?><span class="admin-chat-sender"><?= e($message['mine']?'Vous':$message['sender_name']) ?></span><?php endif; ?>
              <?= nl2br(e($message['text'])) ?>
              <time class="admin-chat-time"><?= e($message['time']) ?></time>
            </article>
          <?php endforeach; endif; ?>
        </div>
        <form class="admin-chat-compose" id="adminChatForm" method="post" action="<?= e(u('/admin-chat?ajax=send')) ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="c" value="<?= $selectedId ?>">
          <label for="adminChatInput" class="sr-only">Ton message</label>
          <textarea name="contenu" id="adminChatInput" maxlength="4000" placeholder="Écris un message…" required></textarea>
          <button class="btn btn-primary" type="submit" id="adminChatSend">Envoyer</button>
        </form>
      </section>
    </div>
  </main>
</div>
<script src="<?= asset('assets/js/admin-chat.js') ?>" defer></script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
