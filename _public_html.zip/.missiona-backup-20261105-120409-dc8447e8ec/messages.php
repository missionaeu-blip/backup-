<?php
require_once __DIR__ . '/includes/functions.php';
if (!is_logged()) { header('Location: ' . u('/connexion')); exit; }
$u = user();
// Interlocuteur Missiona du client : son gestionnaire assigné, sinon
// l'administrateur principal.
$ADMIN_ID = admin_id();
if ($u['role'] !== 'admin' && !empty($u['gestionnaire_id'])) {
    if ($g = gestionnaire_de($u)) { $ADMIN_ID = (int) $g['id']; }
}

function missiona_interet_projet_valide(int $projectId, int $freelanceId): ?array {
    $st = db()->prepare("SELECT * FROM projets WHERE id=? AND freelance_id IS NULL AND statut IN ('nouveau','analyse') LIMIT 1");
    $st->execute([$projectId]);
    $project = $st->fetch();
    if (!$project) return null;
    foreach (calculer_matching($project) as $match) {
        if ((int)($match['freelance']['id'] ?? 0) === $freelanceId && (int)$match['score'] >= 45) return $project;
    }
    return null;
}

function missiona_project_admin_id(array $project, int $fallback): int {
    $st = db()->prepare("SELECT a.id FROM users c JOIN users a ON a.id=c.gestionnaire_id
                         WHERE c.id=? AND a.role='admin' AND COALESCE(a.actif,1)=1 LIMIT 1");
    $st->execute([(int)$project['entreprise_id']]);
    return (int)$st->fetchColumn() ?: $fallback;
}

function missiona_admin_direct_autorise(int $userId, int $adminId, int $defaultAdminId): bool {
    $st = db()->prepare("SELECT 1 FROM users WHERE id=? AND role='admin' AND COALESCE(actif,1)=1 LIMIT 1");
    $st->execute([$adminId]);
    if (!$st->fetchColumn()) return false;
    if ($adminId === $defaultAdminId) return true;
    $st = db()->prepare("SELECT COUNT(*) FROM messages m
                         WHERE ((m.expediteur_id=? AND m.destinataire_id=?) OR (m.expediteur_id=? AND m.destinataire_id=?))");
    $st->execute([$userId,$adminId,$adminId,$userId]);
    return (int)$st->fetchColumn() > 0;
}

/* L'admin discute avec un compte de son périmètre ; les autres
   discutent uniquement avec Missiona. Les conversations sont
   regroupées par projet (voir includes/messagerie.php). */
$pid = 0; $projets = []; $projet = null;
$interestProject = null; $interestDraft = '';
$interestAdminId = 0;
$adminDirectId = 0; $adminDirects = [];
if (isset($_GET['interet'])) {
    if ($u['role'] !== 'freelance') {
        header('Location: ' . u('/messages')); exit;
    }
    $interestProject = missiona_interet_projet_valide((int)$_GET['interet'], (int)$u['id']);
    if (!$interestProject) {
        flash('Cette proposition n’est plus disponible ou ne correspond plus à votre profil.', 'error');
        header('Location: ' . u('/messages')); exit;
    }
    $interestAdminId = missiona_project_admin_id($interestProject, $ADMIN_ID);
    $adminDirectId = $interestAdminId;
    $ad = db()->prepare('SELECT prenom,nom FROM users WHERE id=?');
    $ad->execute([$interestAdminId]);
    $adminName = trim(implode(' ', array_filter($ad->fetch() ?: [])));
    $projectRef = reference_projet_courte($interestProject['reference'] ?? '', $interestProject['id'] ?? 0);
    $freelanceName = trim((string)$u['prenom'] . ' ' . (string)$u['nom']);
    $projectBudget = euros((int)$interestProject['budget_min']) . ' à ' . euros_max((int)$interestProject['budget_max']);
    $projectDeadline = date_fr($interestProject['date_limite'] ?? '');
    $interestDraft = "Bonjour " . ($adminName !== '' ? $adminName : 'l’équipe Missiona') . ",\n\nJe vous confirme mon intérêt pour la mission suivante :\n- Intitulé : " . $interestProject['titre'] . "\n- Référence : " . $projectRef . "\n- Domaine : " . $interestProject['categorie'] . "\n- Budget indicatif : " . $projectBudget . "\n- Délai souhaité : " . ($interestProject['delai'] ?: 'à préciser') . "\n- Échéance : " . $projectDeadline . "\n\nCette mission correspond à mon expérience et à mes compétences. Je serais ravi(e) d’échanger avec vous sur le besoin, le périmètre et les prochaines étapes.\n\nJe reste à votre disposition pour tout complément d’information.\n\nCordialement,\n" . ($freelanceName !== '' ? $freelanceName : 'Votre interlocuteur');
}
if ($u['role'] === 'admin') {
    $projets = msg_projets($u);
    $pid     = (int) ($_GET['p'] ?? 0);
    if ($pid > 0) {
        $projet = msg_projet($pid);
        // Valider par périmètre plutôt que par la liste des 60 derniers
        // projets, afin que la recherche puisse ouvrir aussi un projet ancien.
        $projectScope = msg_perimetre_admin($u);
        $projectVisible = $projet && ($projectScope === null
            || in_array((int)$projet['entreprise_id'], $projectScope, true)
            || in_array((int)($projet['freelance_id'] ?? 0), $projectScope, true));
        if (!$projectVisible) { $pid = 0; $projet = null; }
    }
    $contacts = msg_contacts($u, $pid);
    $ids  = array_map('intval', array_column($contacts, 'id'));
    $cid  = (int) ($_GET['c'] ?? 0);
    if (!in_array($cid, $ids, true)) { $cid = (int) ($contacts[0]['id'] ?? 0); }
    $did  = 0;
} else {
    $contacts = [];
    // Canaux directs ouverts par l'équipe sur certains projets.
    $directs = contact_direct_projets($u);
    $uniques = [];
    foreach ($directs as $dp) { $uniques[(int) $dp['h_id']] = $dp; }
    $directs = array_values($uniques);
    $did = (int) ($_GET['d'] ?? 0);
    $homologue = contact_direct_homologue($u, $did);
    if ($interestProject) {
        $cid = $interestAdminId; $did = 0;
    } elseif ($homologue > 0) {
        $cid = $homologue;
    } else {
        $requestedAdmin = (int)($_GET['a'] ?? 0);
        if ($requestedAdmin > 0 && missiona_admin_direct_autorise((int)$u['id'], $requestedAdmin, $ADMIN_ID)) {
            $adminDirectId = $requestedAdmin;
            $cid = $requestedAdmin; $did = 0;
        } else {
            $cid = $ADMIN_ID; $did = 0;
        }
    }
    $st = db()->prepare("SELECT u.id,u.nom,u.prenom,u.email,MAX(m.id) AS dernier
                         FROM messages m JOIN users u ON u.id=CASE WHEN m.expediteur_id=? THEN m.destinataire_id ELSE m.expediteur_id END
                         WHERE (m.expediteur_id=? OR m.destinataire_id=?)
                           AND u.role='admin' AND COALESCE(u.actif,1)=1 AND u.id<>?
                         GROUP BY u.id ORDER BY dernier DESC");
    $st->execute([$u['id'],$u['id'],$u['id'],$ADMIN_ID]);
    $adminDirects = $st->fetchAll();
}

if (($_GET['live'] ?? '') === 'search') {
    if ($u['role'] !== 'admin') { http_response_code(403); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>false]); exit; }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private, max-age=0');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    $query = trim((string)($_GET['q'] ?? ''));
    $projectsFound = []; $companiesFound = []; $freelancersFound = [];
    if (mb_strlen($query) >= 2) {
        $pattern = '%' . mb_substr($query, 0, 80) . '%';
        $scope = msg_perimetre_admin($u);
        $projectSql = "SELECT p.id,p.reference,p.titre,p.statut,p.entreprise_id,p.freelance_id,
                              c.societe AS c_societe,c.nom AS c_nom,c.prenom AS c_prenom,
                              f.nom AS f_nom,f.prenom AS f_prenom
                       FROM projets p
                       LEFT JOIN users c ON c.id=p.entreprise_id
                       LEFT JOIN users f ON f.id=p.freelance_id
                       WHERE (p.reference LIKE ? OR p.titre LIKE ? OR COALESCE(c.societe,'') LIKE ?
                              OR COALESCE(c.nom,'') LIKE ? OR COALESCE(f.nom,'') LIKE ? OR COALESCE(f.prenom,'') LIKE ?)";
        $projectArgs = [$pattern,$pattern,$pattern,$pattern,$pattern,$pattern];
        if ($scope !== null) {
            if (!$scope) { $projectSql .= ' AND 0=1'; }
            else {
                $marks = implode(',', array_fill(0,count($scope),'?'));
                $projectSql .= " AND (p.entreprise_id IN ($marks) OR p.freelance_id IN ($marks))";
                $projectArgs = array_merge($projectArgs,$scope,$scope);
            }
        }
        $projectSql .= ' ORDER BY p.id DESC LIMIT 10';
        $st = db()->prepare($projectSql); $st->execute($projectArgs);
        foreach ($st->fetchAll() as $row) {
            $client = (string)($row['c_societe'] ?: trim(($row['c_prenom'] ?? '') . ' ' . ($row['c_nom'] ?? '')));
            $expert = trim(($row['f_prenom'] ?? '') . ' ' . ($row['f_nom'] ?? ''));
            $projectsFound[] = [
                'label' => reference_projet_courte($row['reference'] ?? '', $row['id'] ?? 0) . ' · ' . (string)$row['titre'],
                'detail' => 'Projet · ' . ($client ?: 'Client') . ($expert ? ' · ' . $expert : ' · freelance à attribuer') . ' · ' . statut_label($row['statut']),
                'url' => u('/messages?p=' . (int)$row['id']),
            ];
        }

        $userSql = "SELECT id,role,nom,prenom,email,societe,titre_pro FROM users
                    WHERE COALESCE(actif,1)=1 AND role IN ('entreprise','particulier','freelance')
                    AND (COALESCE(nom,'') LIKE ? OR COALESCE(prenom,'') LIKE ? OR COALESCE(email,'') LIKE ?
                         OR COALESCE(societe,'') LIKE ? OR COALESCE(titre_pro,'') LIKE ?)";
        $userArgs = [$pattern,$pattern,$pattern,$pattern,$pattern];
        if ($scope !== null) {
            if (!$scope) { $userSql .= ' AND 0=1'; }
            else { $marks=implode(',',array_fill(0,count($scope),'?')); $userSql .= " AND id IN ($marks)"; $userArgs=array_merge($userArgs,$scope); }
        }
        $userSql .= " ORDER BY role,nom,prenom LIMIT 30";
        $st = db()->prepare($userSql); $st->execute($userArgs);
        foreach ($st->fetchAll() as $row) {
            $isFreelance = $row['role'] === 'freelance';
            $name = trim((string)$row['prenom'] . ' ' . (string)$row['nom']);
            $record = [
                'label' => $isFreelance ? ($name ?: $row['email']) : ((string)($row['societe'] ?: $name) ?: $row['email']),
                'detail' => ($isFreelance ? 'Freelance' : role_label($row['role'])) . ' · ' . ($isFreelance ? ($row['titre_pro'] ?: $row['email']) : $row['email']),
                'url' => u('/messages?c=' . (int)$row['id']),
            ];
            if ($isFreelance) $freelancersFound[] = $record; else $companiesFound[] = $record;
        }
    }
    echo json_encode(['ok'=>true,'projects'=>$projectsFound,'companies'=>$companiesFound,'freelancers'=>$freelancersFound], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}


/* ------------------------------------------------------------------
 * Actualisation légère de la conversation (requêtes AJAX authentifiées).
 * Les interlocuteurs sont toujours recalculés/validés côté serveur.
 * ------------------------------------------------------------------ */
function msg_live_payload(array $m, array $viewer): array
{
    $id = (int)($m['id'] ?? 0);
    $nom = (string)($m['fichier_nom'] ?? '');
    $protege = !empty($m['fichier_protege']);
    $peutTelecharger = !($protege && est_client((string)$viewer['role']));
    return [
        'id' => $id,
        'expediteur_id' => (int)($m['expediteur_id'] ?? 0),
        'is_mine' => (int)($m['expediteur_id'] ?? 0) === (int)$viewer['id'],
        'sender_role' => (string)($m['s_role'] ?? ''),
        'sender_name' => trim((string)($m['s_prenom'] ?? '') . ' ' . (string)($m['s_nom'] ?? '')),
        'contenu' => (string)($m['contenu'] ?? ''),
        'projet_id' => (int)($m['projet_id'] ?? 0),
        'projet_reference' => reference_projet_courte($m['projet_reference'] ?? '', $m['projet_id'] ?? 0),
        'projet_titre' => (string)($m['projet_titre'] ?? ''),
        'fichier_nom' => $nom,
        'fichier_taille' => (int)($m['fichier_taille'] ?? 0),
        'fichier_protege' => $protege,
        'fichier_previsualisable' => $nom !== '' && fichier_previsualisable($nom),
        'fichier_telechargeable' => $nom !== '' && $peutTelecharger,
        'fichier_url' => $nom !== '' && $peutTelecharger ? u('/message-fichier.php?id=' . $id) : '',
        'created_at' => (string)($m['created_at'] ?? ''),
        'heure' => !empty($m['created_at']) ? date('d/m/Y H:i', strtotime((string)$m['created_at'])) : '',
    ];
}

if (($_GET['live'] ?? '') === 'poll') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private');
    $after = max(0, (int)($_GET['after'] ?? 0));
    $rows = [];

    if (isset($_GET['lecture'])) {
        // Vue de surveillance admin : mêmes contrôles de périmètre que la page.
        if ($u['role'] !== 'admin') { http_response_code(403); echo json_encode(['ok'=>false]); exit; }
        $lid = (int)$_GET['lecture'];
        $lp = msg_projet($lid);
        $scope = $lp && in_array($lid, array_column(msg_projets($u), 'id'), true);
        if (!$scope) { http_response_code(403); echo json_encode(['ok'=>false]); exit; }
        $eId = (int)$lp['entreprise_id'];
        $fId = (int)$lp['freelance_id'];
        $st = db()->prepare("SELECT m.*, p.reference AS projet_reference, p.titre AS projet_titre,
                                    u.nom AS s_nom, u.prenom AS s_prenom, u.role AS s_role
                             FROM messages m LEFT JOIN users u ON u.id=m.expediteur_id
                             LEFT JOIN projets p ON p.id=m.projet_id
                             WHERE ((m.expediteur_id=? AND m.destinataire_id=?) OR (m.expediteur_id=? AND m.destinataire_id=?))
                               AND m.id>? ORDER BY m.id ASC LIMIT 100");
        $st->execute([$eId, $fId, $fId, $eId, $after]);
        $rows = $st->fetchAll();
    } else {
        if ($cid > 0) {
            // L'ouverture de la conversation marque aussi les nouveaux messages lus.
            db()->prepare("UPDATE messages SET lu=1 WHERE destinataire_id=? AND expediteur_id=?")
                ->execute([$u['id'], $cid]);
            $st = db()->prepare("SELECT m.*, p.reference AS projet_reference, p.titre AS projet_titre,
                                        u.nom AS s_nom, u.prenom AS s_prenom, u.role AS s_role
                                 FROM messages m LEFT JOIN users u ON u.id=m.expediteur_id
                                 LEFT JOIN projets p ON p.id=m.projet_id
                                 WHERE ((m.expediteur_id=? AND m.destinataire_id=?) OR (m.expediteur_id=? AND m.destinataire_id=?))
                                   AND m.id>? ORDER BY m.id ASC LIMIT 100");
            $st->execute([$u['id'], $cid, $cid, $u['id'], $after]);
            $rows = $st->fetchAll();
        }
    }
    $out = [];
    foreach ($rows as $row) $out[] = msg_live_payload($row, $u);
    echo json_encode(['ok'=>true, 'messages'=>$out], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

/* ------------------------------------------------------------------
 * Surveillance équipe : lecture seule du fil direct entreprise↔expert
 * d'un projet. Réservée à l'administrateur, et uniquement pour les
 * projets de son périmètre.
 * ------------------------------------------------------------------ */
if ($u['role'] !== 'admin' && isset($_GET['lecture'])) {
    header('Location: ' . u('/messages')); exit;   // ce lien n'existe pas hors équipe
}
if ($u['role'] === 'admin' && isset($_GET['lecture'])) {
    $lid = (int) $_GET['lecture'];
    $lp  = msg_projet($lid);
    $dans_perimetre = $lp && in_array($lid, array_column(msg_projets($u), 'id'), true);
    if (!$dans_perimetre) { header('Location: ' . u('/messages')); exit; }

    $e_id = (int) $lp['entreprise_id'];
    $f_id = (int) $lp['freelance_id'];
    $sl = db()->prepare("SELECT m.*, u.nom AS s_nom, u.prenom AS s_prenom, u.role AS s_role, u.societe AS s_societe
                         FROM messages m LEFT JOIN users u ON u.id = m.expediteur_id
                         WHERE (m.expediteur_id=? AND m.destinataire_id=?)
                            OR (m.expediteur_id=? AND m.destinataire_id=?)
                         ORDER BY m.id ASC");
    $sl->execute([$e_id, $f_id, $f_id, $e_id]);
    $lmsgs = $sl->fetchAll();

    $titre = "Contact direct — " . $lp['titre'];
    require_once __DIR__ . '/includes/header.php';
    ?>
    <div class="app app-chat">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <main class="main main-chat">
      <div class="page-head">
        <div>
          <h1>Contact direct — lecture seule</h1>
          <p><?= e($lp['titre']) ?> · <?= e(msg_projet_libelle($lp)) ?> ↔ <?= e(trim(($lp['f_prenom'] ?? '') . ' ' . ($lp['f_nom'] ?? ''))) ?></p>
        </div>
        <a href="<?= u('/messages') ?>" class="btn btn-ghost">← Retour à la messagerie</a>
      </div>

      <div class="chat">
        <div class="chat-main" style="max-width:none">
          <div class="chat-note">
            👁 Fil échangé en direct entre le client et l'expert
            <?= empty($lp['statut']) || $lp['statut'] !== 'annule' ? '' : ' (projet annulé)' ?>.
            Vous le consultez sans pouvoir y écrire : la réponse officielle passe par votre propre conversation.
          </div>
          <div class="chat-body" id="chatBody" data-user-id="<?= (int)$u['id'] ?>" data-readonly="1">
            <?php if (!$lmsgs): ?>
              <div class="empty" style="margin:auto">
                <div class="ico">💬</div>
                <h3>Aucun échange direct pour l'instant</h3>
                <p>Les messages envoyés sur ce canal apparaîtront ici.</p>
              </div>
            <?php else: foreach ($lmsgs as $m):
              $qui = $m['s_role'] === 'freelance'
                  ? trim(($m['s_prenom'] ?? '') . ' ' . ($m['s_nom'] ?? ''))
                  : (($m['s_societe'] ?? '') ?: trim(($m['s_prenom'] ?? '') . ' ' . ($m['s_nom'] ?? '')));
            ?>
              <div class="msg <?= ($m['s_role'] ?? '') === 'freelance' ? 'out' : 'in' ?>" data-message-id="<?= (int)$m['id'] ?>">
                <span class="badge badge-gray" style="font-size:.62rem;margin-bottom:4px"><?= e($qui ?: 'Compte supprimé') ?></span>
                <?= nl2br(e($m['contenu'])) ?>
                <?php if (!empty($m['fichier_nom'])): ?>
                  <div class="msg-pj">
                    <span class="msg-pj-ico"><?= icone_fichier($m['fichier_nom']) ?></span>
                    <span class="msg-pj-nom"><?= e($m['fichier_nom']) ?></span>
                    <span class="msg-pj-taille"><?= taille_lisible($m['fichier_taille']) ?></span>
                    <span class="msg-pj-actions">
                      <?php if (fichier_previsualisable($m['fichier_nom'])): ?>
                        <button type="button" data-apercu-msg="<?= (int) $m['id'] ?>"
                                data-nom="<?= e($m['fichier_nom']) ?>" data-suivi-non>👁</button>
                      <?php endif; ?>
                      <a href="<?= u('/message-fichier.php?id=' . (int) $m['id']) ?>" title="Télécharger">⬇</a>
                    </span>
                  </div>
                <?php endif; ?>
                <span class="time"><?= date('d/m/Y H:i', strtotime($m['created_at'])) ?></span>
              </div>
            <?php endforeach; endif; ?>
          </div>
          <div class="chat-foot" style="justify-content:center;color:var(--muted);font-size:.8125rem">
            🔒 Consultation seule — l'envoi de messages sur ce canal est réservé aux deux parties.
          </div>
        </div>
      </div>
    </main>
    </div>
    <script src="<?= asset('assets/js/messagerie-live.js') ?>" defer></script>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Envoi d'un message
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $txt = trim($_POST['contenu'] ?? '');
    $projet_msg = null; // projet associé au message, sinon NULL
    $interestMode = false;
    $adminDirectPost = 0;
    $interestPost = 0;
    if ($u['role'] === 'admin') {
        // Seul l'admin choisit son destinataire.
        $dest = (int)($_POST['dest'] ?? $cid);
        // Un administrateur non principal ne peut écrire qu'aux comptes dont
        // il a la charge, même s'il force l'identifiant dans le formulaire.
        if (!msg_peut_ecrire($u, $dest)) { $dest = 0; }
    } else {
        // Une manifestation d'intérêt validée est rattachée au projet et
        // envoyée à l'administrateur de compte; le brouillon n'est jamais
        // transmis avant validation explicite par le freelance.
        $interestPost = (int)($_POST['interest_project'] ?? 0);
        $interestMode = false;
        $adminDirectPost = 0;
        $d_post = (int)($_POST['d'] ?? 0);
        if ($interestPost > 0 && $u['role'] === 'freelance') {
            $verifiedInterest = missiona_interet_projet_valide($interestPost, (int)$u['id']);
            if ($verifiedInterest) {
                $dest = missiona_project_admin_id($verifiedInterest, $ADMIN_ID);
                $projet_msg = $interestPost;
                $interestMode = true;
            } else {
                $dest = 0;
            }
        } elseif ($d_post > 0 && ($directDest = contact_direct_homologue($u, $d_post)) > 0) {
            $dest = $directDest;
            $projet_msg = $d_post;
        } else {
            $requestedAdmin = (int)($_POST['a'] ?? 0);
            if ($requestedAdmin > 0 && missiona_admin_direct_autorise((int)$u['id'], $requestedAdmin, $ADMIN_ID)) {
                $dest = $requestedAdmin;
                $adminDirectPost = $requestedAdmin;
            } else {
                $dest = $ADMIN_ID;
            }
        }
        if (!$dest && ($_POST['_ajax'] ?? '') === '1') {
            http_response_code(422);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok'=>false,'error'=>'Cette proposition n’est plus disponible.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        if (!$dest && $interestPost > 0) {
            flash('Cette proposition n’est plus disponible. Aucun message n’a été envoyé.', 'error');
            header('Location: ' . u('/messages')); exit;
        }
    }
    // Pièce jointe éventuelle
    $pj = ['nom' => '', 'chemin' => '', 'taille' => 0, 'empreinte' => ''];
    if ($dest && !empty($_FILES['piece']['name'])) {
        $r = traiter_upload($_FILES['piece'], 'messages', ext_doc_autorisees());
        if ($r['ok']) {
            $pj = [
                'nom'       => $r['nom'],
                'chemin'    => $r['chemin'],
                'taille'    => (int) $r['taille'],
                'empreinte' => @hash_file('sha256', __DIR__ . '/uploads/' . $r['chemin']) ?: '',
            ];
            if ($txt === '') { $txt = 'Pièce jointe : ' . $r['nom']; }
        } else {
            if (($_POST['_ajax'] ?? '') === '1') {
                http_response_code(422);
                header('Content-Type: application/json; charset=utf-8');
                header('Cache-Control: no-store, private');
                echo json_encode(['ok'=>false, 'error'=>(string)$r['erreur']], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
                exit;
            }
            flash($r['erreur'], 'error');
            header('Location: ' . u('messages.php' . ($u['role']==='admin' && $dest ? '?c='.$dest : ''))); exit;
        }
    }

    // Un document remis à une entreprise est protégé : consultation avec
    // filigrane, téléchargement contrôlé. Ce qui circule vers l'équipe ou
    // vers un expert n'a pas besoin de ce traitement.
    $protege = 0;
    if ($pj['nom'] !== '') {
        $dr = db()->prepare("SELECT role FROM users WHERE id = ?");
        $dr->execute([$dest]);
        $protege = in_array((string) $dr->fetchColumn(), ['entreprise', 'particulier'], true) ? 1 : 0;
    }

    $nouveau_id = 0;
    if ($txt !== '' && $dest) {
        $ins = db()->prepare("INSERT INTO messages (projet_id,expediteur_id,destinataire_id,contenu,
                              fichier_nom,fichier_chemin,fichier_taille,fichier_empreinte,fichier_protege)
                       VALUES (?,?,?,?,?,?,?,?,?)");
        $ins->execute([$projet_msg, $u['id'], $dest, $txt, $pj['nom'], $pj['chemin'], $pj['taille'], $pj['empreinte'], $protege]);
        $nouveau_id = (int) db()->lastInsertId();

        $qui = ($u['role'] === 'admin') ? 'Missiona' : trim($u['prenom'] . ' ' . $u['nom']);
        if ($interestMode && $projet_msg) {
            $ref = reference_projet_courte($verifiedInterest['reference'] ?? '', $projet_msg);
            notify($dest, "Intérêt confirmé de " . $qui . " pour « " . $verifiedInterest['titre'] . " » (" . $ref . ").",
                   'messages.php?p=' . (int)$projet_msg . '&c=' . (int)$u['id']);
        } elseif ($projet_msg) {
            // Canal direct projet : le destinataire est prévenu, l'équipe
            // conserve le lien de consultation prévu pour ce fil.
            notify($dest, "Nouveau message de " . $qui . " (contact direct).", 'messages.php?d=' . (int) $projet_msg);
            $na = db()->prepare("SELECT id FROM users WHERE role='admin' AND actif=1");
            $na->execute();
            foreach ($na as $ad) {
                if ((int) $ad['id'] !== (int) $u['id']) {
                    notify((int) $ad['id'],
                        "Échange direct sur « " . msg_titre_projet($projet_msg) . " » : message de " . $qui . ".",
                        'messages.php?lecture=' . (int) $projet_msg);
                }
            }
        } else {
            $notifyLink = $u['role'] === 'admin'
                ? 'messages.php?a=' . (int)$u['id']
                : 'messages.php?c=' . (int)$u['id'];
            notify($dest, "Nouveau message de " . $qui . ".", $notifyLink);
        }
    }
    if (($_POST['_ajax'] ?? '') === '1') {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, private');
        $message = null;
        if ($nouveau_id > 0) {
            $q = db()->prepare("SELECT m.*, p.reference AS projet_reference, p.titre AS projet_titre,
                                        x.nom AS s_nom, x.prenom AS s_prenom, x.role AS s_role
                                FROM messages m LEFT JOIN users x ON x.id=m.expediteur_id
                                LEFT JOIN projets p ON p.id=m.projet_id WHERE m.id=?");
            $q->execute([$nouveau_id]);
            $row = $q->fetch();
            if ($row) $message = msg_live_payload($row, $u);
        }
        echo json_encode(['ok'=>true, 'message'=>$message, 'admin_direct_id'=>$interestMode ? (int)$dest : 0], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }

    $retour = 'messages.php';
    if ($u['role'] === 'admin' && $dest) {
        $retour .= '?c=' . $dest . (!empty($_POST['p']) ? '&p=' . (int) $_POST['p'] : '');
    } elseif ($u['role'] !== 'admin' && $interestMode) {
        $retour .= '?a=' . (int)$dest;
    } elseif ($u['role'] !== 'admin' && $adminDirectPost > 0) {
        $retour .= '?a=' . $adminDirectPost;
    } elseif ($u['role'] !== 'admin' && $projet_msg) {
        $retour .= '?d=' . (int) $projet_msg;
    }
    header('Location: ' . u($retour)); exit;
}

// Marquer comme lus
db()->prepare("UPDATE messages SET lu=1 WHERE destinataire_id=? AND expediteur_id=?")->execute([$u['id'], $cid]);

$st = db()->prepare("SELECT m.*, p.reference AS projet_reference, p.titre AS projet_titre
                     FROM messages m LEFT JOIN projets p ON p.id=m.projet_id
                     WHERE (m.expediteur_id=? AND m.destinataire_id=?) OR (m.expediteur_id=? AND m.destinataire_id=?)
                     ORDER BY m.id ASC");
$st->execute([$u['id'], $cid, $cid, $u['id']]);
$msgs = $st->fetchAll();

$cs = db()->prepare("SELECT * FROM users WHERE id=?"); $cs->execute([$cid]);
$contact = $cs->fetch();

$titre = "Messagerie";
require_once __DIR__ . '/includes/header.php';
?>
<?php if ($u['role']==='admin'): ?>
<style>
.admin-msg-search{position:sticky;top:0;z-index:8;padding:12px;background:var(--surface);border-bottom:1px solid var(--line)}
.admin-msg-search label{display:block;font-size:.72rem;font-weight:700;color:var(--muted);margin-bottom:7px}
.admin-msg-search .input{width:100%;min-width:0}
.admin-msg-search-results{max-height:46vh;overflow:auto;margin-top:8px;border:1px solid var(--line);border-radius:10px;background:#fff;box-shadow:0 8px 22px #10182818}
.admin-msg-search-results[hidden]{display:none}
.admin-msg-search-group{padding:8px 10px 4px;font-size:.68rem;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
.admin-msg-search-result{display:block;padding:9px 11px;color:var(--text);text-decoration:none;border-top:1px solid var(--line-2)}
.admin-msg-search-result:hover,.admin-msg-search-result:focus{background:var(--blue-light);outline:0}
.admin-msg-search-result strong{display:block;font-size:.82rem}
.admin-msg-search-result small{display:block;color:var(--muted);font-size:.72rem;margin-top:2px}
.admin-msg-search-empty{padding:12px;color:var(--muted);font-size:.8rem}
html.admin-messages-fullscreen,body.admin-messages-fullscreen{overflow:hidden!important}
body.admin-messages-fullscreen>header.header{display:none!important}
body.admin-messages-fullscreen .app-chat{position:fixed!important;inset:0!important;z-index:100000!important;display:block!important;width:100vw!important;height:100vh!important;height:100dvh!important;min-height:0!important;max-height:none!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;overflow:hidden!important;background:var(--bg,#f5f7fb)!important;isolation:isolate}
body.admin-messages-fullscreen .app-chat>.sidebar{display:none!important}
body.admin-messages-fullscreen .app-chat>.main-chat{position:absolute!important;inset:0!important;display:flex!important;flex-direction:column!important;box-sizing:border-box!important;width:100%!important;height:100%!important;min-width:0!important;min-height:0!important;max-height:none!important;margin:0!important;padding:14px!important;overflow:hidden!important;background:var(--bg,#f5f7fb)!important}
body.admin-messages-fullscreen .app-chat .page-head{flex:0 0 auto!important;width:100%!important;margin:0 0 10px!important}
body.admin-messages-fullscreen .app-chat .chat{display:grid!important;grid-template-columns:minmax(230px,320px) minmax(0,1fr)!important;flex:1 1 auto!important;width:100%!important;height:auto!important;min-width:0!important;min-height:0!important;max-height:none!important;margin:0!important;gap:12px!important;overflow:hidden!important}
body.admin-messages-fullscreen .app-chat .chat-list{min-width:0!important;min-height:0!important;height:100%!important;max-height:none!important;overflow-y:auto!important;overscroll-behavior:contain}
body.admin-messages-fullscreen .app-chat .chat-main{display:flex!important;flex-direction:column!important;min-width:0!important;min-height:0!important;height:100%!important;max-height:none!important;overflow:hidden!important}
body.admin-messages-fullscreen .app-chat .chat-head{flex:0 0 auto!important}
body.admin-messages-fullscreen .app-chat .chat-body{flex:1 1 auto!important;min-height:0!important;height:auto!important;max-height:none!important;overflow-y:auto!important}
body.admin-messages-fullscreen .app-chat .chat-foot{flex:0 0 auto!important}
body.admin-messages-fullscreen .footer{display:none!important}
@media(max-width:700px){body.admin-messages-fullscreen .app-chat>.main-chat{padding:8px!important}body.admin-messages-fullscreen .app-chat .chat{grid-template-columns:minmax(120px,38vw) minmax(0,1fr)!important;gap:6px!important}}
</style>
<?php endif; ?>
<div class="app app-chat">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main main-chat">

  <div class="page-head">
    <div>
      <h1>Messagerie</h1>
      <p><?php if ($u['role']!=='admin'): ?>Échangez avec votre chargé de compte Missiona.
          <?php elseif (msg_admin_global($u)): ?>Échanges avec l'ensemble des entreprises et des experts.
          <?php else: ?>Échanges avec les comptes dont vous avez la charge.<?php endif; ?></p>
    </div>
    <?php if ($u['role']==='admin'): ?>
      <button type="button" class="btn btn-ghost" id="adminMessagesFullscreen" aria-pressed="false">⛶ Plein écran</button>
    <?php endif; ?>
  </div>

  <div class="chat">
    <div class="chat-list">
      <?php if ($u['role']==='admin'): ?>
        <div class="admin-msg-search">
          <label for="adminMessageSearch">Rechercher un projet, une entreprise ou un freelance</label>
          <input type="search" id="adminMessageSearch" class="input" placeholder="Nom, référence ou projet…" autocomplete="off" aria-controls="adminMessageSearchResults">
          <div id="adminMessageSearchResults" class="admin-msg-search-results" role="listbox" hidden></div>
        </div>

        <?php if ($projet): ?>
          <!-- Un projet est ouvert : seuls ses deux interlocuteurs -->
          <a href="<?= u('/messages') ?>" class="chat-retour">← Tous les projets</a>
          <div class="chat-projet-titre">
            <strong><?= e(reference_projet_courte($projet['reference'] ?? '', $projet['id'] ?? 0)) ?> · <?= e($projet['titre']) ?></strong>
            <span class="small muted"><?= e(msg_projet_libelle($projet)) ?></span>
          </div>
        <?php elseif ($projets): ?>
          <div class="chat-section">Projets</div>
          <?php foreach ($projets as $p):
            $nbp = 0;
            $participantsProjet = ((int)$p['id'] === (int)$pid && $projet)
                ? array_map('intval', array_column($contacts, 'id'))
                : [(int)$p['entreprise_id'], (int)$p['freelance_id']];
            foreach (array_unique($participantsProjet) as $x) {
              if ($x > 0) { $nbp += msg_non_lus($u['id'], $x); }
            }
          ?>
            <a href="<?= u('/messages?p=' . (int) $p['id']) ?>" class="chat-item">
              <span class="avatar">📁</span>
              <div class="meta">
                <strong><?= e(stats_tronquer($p['titre'], 26)) ?><?php if($nbp):?>
                  <span class="badge badge-red" style="font-size:.625rem"><?= $nbp ?></span><?php endif;?></strong>
                <p><?= e(reference_projet_courte($p['reference'] ?? '', $p['id'] ?? 0)) ?> · <?= e(msg_projet_libelle($p)) ?></p>
                <p style="font-size:.75rem"><?= e(statut_label($p['statut'])) ?>
                  · <?= $p['freelance_id'] ? '2 interlocuteurs' : '1 interlocuteur' ?></p>
              </div>
            </a>
          <?php endforeach; ?>
          <div class="chat-section">Tous les comptes</div>
        <?php endif; ?>

        <?php if ($surv = contact_direct_surveillance($u)): ?>
          <div class="chat-section">Contacts directs (lecture)</div>
          <?php foreach ($surv as $s): ?>
            <a href="<?= u('/messages?lecture=' . (int) $s['id']) ?>" class="chat-item">
              <span class="avatar">🔓</span>
              <div class="meta">
                <strong><?= e(stats_tronquer($s['titre'], 26)) ?></strong>
                <p><?= e(msg_projet_libelle($s)) ?> ↔ <?= e(trim(($s['f_prenom'] ?? '') . ' ' . mb_substr((string) ($s['f_nom'] ?? ''), 0, 1) . '.')) ?></p>
                <p style="font-size:.75rem"><?= (int) $s['nb'] ?> message<?= (int) $s['nb'] > 1 ? 's' : '' ?> · lecture seule</p>
              </div>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>

        <?php if (!$contacts): ?>
          <div style="padding:18px;font-size:.8125rem;color:var(--muted)">
            <?= $projet
                ? "Aucun interlocuteur joignable sur ce projet."
                : "Aucun compte ne vous est rattaché pour le moment." ?>
          </div>
        <?php endif; ?>

        <?php foreach ($contacts as $c):
          $last = msg_dernier($u['id'], $c['id']);
          $nb   = msg_non_lus($u['id'], $c['id']);
          $lien = '/messages?c=' . (int) $c['id'] . ($pid ? '&p=' . $pid : '');
        ?>
          <a href="<?= u($lien) ?>" class="chat-item <?= $c['id']==$cid?'active':'' ?>">
            <span class="avatar"><?= initiales($c) ?></span>
            <div class="meta">
              <strong><?= e(trim($c['prenom'].' '.$c['nom'])) ?><?php if($nb):?> <span class="badge badge-red" style="font-size:.625rem"><?= $nb ?></span><?php endif;?></strong>
              <p>
                <?= e(est_client($c['role']) ? ($c['societe'] ?: role_label($c['role'])) : $c['titre_pro']) ?>
                <?php if ($projet): ?>
                  <span class="badge badge-gray" style="font-size:.625rem"><?= est_client($c['role']) ? 'Client' : 'Expert' ?></span>
                <?php endif; ?>
              </p>
              <p style="font-size:.75rem"><?= e(mb_substr((string)$last, 0, 42)) ?><?= mb_strlen((string)$last)>42?'…':'' ?></p>
            </div>
          </a>
        <?php endforeach; ?>
      <?php else: ?>
        <a href="<?= u('/messages') ?>" class="chat-item <?= $did === 0 && ($adminDirectId === 0 || $adminDirectId === $ADMIN_ID) ? 'active' : '' ?>">
          <span class="avatar dark">WC</span>
          <div class="meta">
            <strong>Missiona <?php if (msg_non_lus($u['id'], $ADMIN_ID)): ?><span class="badge badge-red" style="font-size:.625rem"><?= msg_non_lus($u['id'], $ADMIN_ID) ?></span><?php endif; ?></strong>
            <p><?= e(charge_compte_nom()) ?> — <?= e(charge_compte_role()) ?></p>
          </div>
        </a>

        <?php if ($adminDirects): ?>
          <div class="chat-section">Équipe Missiona</div>
          <?php foreach ($adminDirects as $adminContact): $adminUnread = msg_non_lus($u['id'], (int)$adminContact['id']); ?>
            <a href="<?= u('/messages?a=' . (int)$adminContact['id']) ?>" class="chat-item <?= $adminDirectId === (int)$adminContact['id'] ? 'active' : '' ?>">
              <span class="avatar dark"><?= initiales($adminContact) ?></span>
              <div class="meta">
                <strong><?= e(trim($adminContact['prenom'].' '.$adminContact['nom']) ?: $adminContact['email']) ?><?php if ($adminUnread): ?> <span class="badge badge-red" style="font-size:.625rem"><?= $adminUnread ?></span><?php endif; ?></strong>
                <p>Conversation directe avec l’équipe admin</p>
              </div>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>

        <?php if ($directs): ?>
          <div class="chat-section">Contact direct</div>
          <?php foreach ($directs as $dp):
            $nb_d = msg_non_lus($u['id'], (int) $dp['h_id']);
            $nom_d = est_client($dp['h_role'])
                ? ($dp['h_societe'] ?: trim($dp['h_prenom'] . ' ' . $dp['h_nom']))
                : trim($dp['h_prenom'] . ' ' . $dp['h_nom']);
          ?>
            <a href="<?= u('/messages?d=' . (int) $dp['id']) ?>" class="chat-item <?= (int)$dp['h_id'] === (int)$cid && $did > 0 ? 'active' : '' ?>">
              <span class="avatar"><?= initiales(['prenom' => $dp['h_prenom'], 'nom' => $dp['h_nom']]) ?></span>
              <div class="meta">
                <strong><?= e($nom_d) ?><?php if ($nb_d): ?> <span class="badge badge-red" style="font-size:.625rem"><?= $nb_d ?></span><?php endif; ?></strong>
                <p><?= e($dp['h_role'] === 'freelance' ? ($dp['h_titre'] ?: 'Expert') : 'Client') ?> · <?= e(stats_tronquer($dp['titre'], 30)) ?></p>
                <span class="badge badge-green" style="font-size:.6rem;margin-top:4px">Canal ouvert par Missiona</span>
              </div>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>

        <div style="padding:18px;font-size:.8125rem;color:var(--muted);border-top:1px solid var(--line-2)">
          🔒 Vos échanges passent par votre chargé de compte.
          <?php if ($directs): ?>
            Un canal direct a été ouvert par Missiona sur <?= count($directs) > 1 ? 'certains projets' : 'le projet' ?> ci-dessus.
          <?php else: ?>
            Aucun contact direct entre entreprise et freelance n'est ouvert pour le moment.
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="chat-main">
      <?php $en_direct = ($u['role'] !== 'admin' && $did > 0 && $contact); ?>
      <?php $en_admin_direct = ($u['role'] !== 'admin' && $adminDirectId > 0 && $contact); ?>
      <div class="chat-head">
        <span class="avatar <?= $u['role']==='admin'?'':'dark' ?>">
          <?= $u['role']==='admin' ? ($contact ? initiales($contact) : '?') : (($en_direct || $en_admin_direct) ? initiales($contact) : 'WC') ?>
        </span>
        <div>
          <strong>
            <?php if ($u['role']==='admin'): ?><?= $contact ? e(trim($contact['prenom'].' '.$contact['nom'])) : 'Aucun contact' ?>
            <?php elseif ($en_direct || $en_admin_direct): ?><?= e(trim($contact['prenom'].' '.$contact['nom'])) ?>
            <?php else: ?>Missiona<?php endif; ?>
          </strong>
          <p class="small muted">
            <?php if ($u['role'] !== 'admin'): ?>
              <?php if ($en_direct): ?>
                <?= e(est_client($contact['role']) ? ($contact['societe'] ?: role_label($contact['role'])) : ($contact['titre_pro'] ?: 'Expert')) ?>
              <?php elseif ($en_admin_direct): ?>
                Conversation directe avec l’équipe Missiona
              <?php else: ?>
                <?= e(charge_compte_nom()) ?> — <?= e(charge_compte_role()) ?>
              <?php endif; ?>
            <?php elseif ($contact): ?>
              <?= e(est_client($contact['role']) ? ($contact['societe'] ?: role_label($contact['role'])) : $contact['titre_pro']) ?>
            <?php else: ?>
              Aucune entreprise ni freelance inscrit pour le moment.
            <?php endif; ?>
          </p>
        </div>
      </div>

      <?php if ($u['role'] !== 'admin'): ?>
        <?php if ($interestProject): ?>
          <div class="chat-note" id="interestDraftNote">✍️ Brouillon prérempli pour le projet <?= e(reference_projet_courte($interestProject['reference'] ?? '', $interestProject['id'] ?? 0)) ?>. Relisez-le et modifiez-le si besoin : rien ne sera envoyé avant votre validation.</div>
        <?php elseif ($en_direct): ?>
          <div class="chat-note">🔓 Canal direct ouvert par Missiona sur « <?= e(msg_titre_projet($did)) ?> » — l'équipe Missiona peut consulter ces échanges.</div>
        <?php elseif ($en_admin_direct): ?>
          <div class="chat-note">Conversation directe avec un administrateur Missiona.</div>
        <?php else: ?>
          <div class="chat-note">Conversation sécurisée avec votre chargé de compte Missiona</div>
        <?php endif; ?>
      <?php endif; ?>

      <div class="chat-body" id="chatBody" data-user-id="<?= (int)$u['id'] ?>" data-readonly="0">
        <?php if (!$msgs): ?>
          <div class="empty" style="margin:auto">
            <div class="ico">💬</div>
            <h3>Aucun message</h3>
            <p>Démarrez la conversation ci-dessous.</p>
          </div>
        <?php else: foreach ($msgs as $m): ?>
          <div class="msg <?= $m['expediteur_id']==$u['id'] ? 'out' : 'in' ?>" data-message-id="<?= (int)$m['id'] ?>" data-sender-id="<?= (int)$m['expediteur_id'] ?>">
            <?php if (!empty($m['projet_reference'])): ?><span class="badge badge-gray" style="font-size:.62rem;margin-bottom:5px">Réf. <?= e(reference_projet_courte($m['projet_reference'], $m['projet_id'] ?? 0)) ?> · <?= e($m['projet_titre'] ?? '') ?></span><br><?php endif; ?>
            <?= nl2br(e($m['contenu'])) ?>
            <?php if (!empty($m['fichier_nom'])): ?>
              <div class="msg-pj">
                <span class="msg-pj-ico"><?= icone_fichier($m['fichier_nom']) ?></span>
                <span class="msg-pj-nom"><?= e($m['fichier_nom']) ?></span>
                <span class="msg-pj-taille"><?= taille_lisible($m['fichier_taille']) ?></span>
                <?php if (!empty($m['fichier_protege'])): ?>
                  <span class="badge badge-amber" style="font-size:.62rem">Protégé</span>
                <?php endif; ?>
                <span class="msg-pj-actions">
                  <?php if (fichier_previsualisable($m['fichier_nom'])): ?>
                    <button type="button" data-apercu-msg="<?= (int) $m['id'] ?>"
                            data-nom="<?= e($m['fichier_nom']) ?>" data-suivi-non>👁</button>
                  <?php endif; ?>
                  <?php /* Document protégé remis à une entreprise : consultation seule. */ ?>
                  <?php if (!( !empty($m['fichier_protege']) && est_client($u['role']) )): ?>
                    <a href="<?= u('/message-fichier.php?id=' . (int) $m['id']) ?>" title="Télécharger">⬇</a>
                  <?php endif; ?>
                </span>
              </div>
            <?php endif; ?>
            <span class="time"><?= date('d/m/Y H:i', strtotime($m['created_at'])) ?></span>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <div id="chatLiveStatus" class="small muted" aria-live="polite" hidden></div>
      <form class="chat-foot" id="chatForm" method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <?php if ($u['role'] === 'admin'): ?>
          <input type="hidden" name="dest" value="<?= $cid ?>">
          <input type="hidden" name="p" value="<?= (int) ($pid ?? 0) ?>">
        <?php else: ?>
          <?php if ($interestProject): ?>
            <input type="hidden" name="interest_project" value="<?= (int)$interestProject['id'] ?>">
          <?php elseif ($adminDirectId > 0): ?>
            <input type="hidden" name="a" value="<?= $adminDirectId ?>">
          <?php else: ?>
            <!-- Le serveur revalide le canal direct projet avant tout envoi. -->
            <input type="hidden" name="d" value="<?= (int) $did ?>">
          <?php endif; ?>
        <?php endif; ?>
        <label class="chat-joindre" title="Joindre un document">
          📎
          <input type="file" name="piece" id="chatPiece" hidden
                 accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip,.jpg,.jpeg,.png,.gif,.webp,.html,.htm,.js,.css,.json,.md,.php,.py,.sql">
        </label>
        <textarea name="contenu" class="input" rows="<?= $interestProject ? 6 : 2 ?>" placeholder="Écrivez votre message…" autocomplete="off" required style="resize:vertical;min-height:48px;max-height:180px"><?= e($interestDraft) ?></textarea>
        <button type="submit" class="btn btn-primary">Envoyer</button>
      </form>
    </div>
  </div>

</main>
</div>

<!-- Aperçu protégé des pièces jointes -->
<div class="apercu" id="apercu" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-label="Aperçu du document">
  <div class="apercu-barre">
    <strong id="apercuNom"></strong>
    <span class="apercu-mention">Document confidentiel — diffusion interdite</span>
    <button type="button" class="apercu-fermer" id="apercuFermer" aria-label="Fermer l'aperçu" data-suivi-non>&times;</button>
  </div>
  <div class="apercu-scene" id="apercuScene">
    <div class="apercu-contenu" id="apercuContenu"></div>
    <div class="apercu-filigrane" aria-hidden="true"
         data-texte="<?= e(SITE_NOM) ?>"
         data-qui="<?= e(trim(($u['prenom'] ?? '') . ' ' . ($u['nom'] ?? '')) . ' · ' . date('d/m/Y')) ?>"></div>
    <div class="apercu-voile" id="apercuVoile" hidden>
      <div>Aperçu masqué<br><span>Revenez sur cette fenêtre pour afficher le document.</span></div>
    </div>
  </div>
</div>

<script src="<?= asset('assets/js/messagerie-live.js') ?>" defer></script>
<?php if ($u['role']==='admin'): ?><script src="<?= asset('assets/js/admin-messages.js') ?>" defer></script><?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
