<?php
/** Profil de l'expert affecté à un projet, visible uniquement par les parties autorisées. */
require_once __DIR__ . '/includes/functions.php';
if (!is_logged()) { header('Location: ' . u('/connexion')); exit; }
$u = user();
$projet_id = (int)($_GET['projet'] ?? 0);
$st = db()->prepare("SELECT p.id AS project_record_id,p.reference AS project_reference,p.titre AS project_title,
                            p.entreprise_id,p.freelance_id,p.statut AS project_status,f.*
                     FROM projets p
                     JOIN users f ON f.id=p.freelance_id AND f.role='freelance'
                     WHERE p.id=?");
$st->execute([$projet_id]);
$projet = $st->fetch();
$autorise = $projet && (
    (int)$projet['entreprise_id'] === (int)$u['id']
    || (($u['role'] ?? '') === 'admin' && peut_gerer_projet($projet))
    || (($u['role'] ?? '') === 'freelance' && (int)$projet['freelance_id'] === (int)$u['id'])
);
if (!$autorise) {
    http_response_code(403);
    flash("Ce profil est accessible uniquement depuis un projet auquel vous participez.", 'error');
    header('Location: ' . dashboard_url($u['role'] ?? null, true));
    exit;
}
$forfaits = forfaits_de((int)$projet['freelance_id']);
$portfolio = portfolio_de((int)$projet['freelance_id']);
$competences = array_values(array_filter(array_map('trim', explode(',', (string)$projet['competences']))));
$missions = db()->prepare("SELECT COUNT(*) FROM projets WHERE freelance_id=? AND statut='termine'");
$missions->execute([(int)$projet['freelance_id']]);
$nb_missions = (int)$missions->fetchColumn();
$titre = 'Profil expert — ' . trim($projet['prenom'] . ' ' . $projet['nom']);
require_once __DIR__ . '/includes/header.php';
?>
<div class="app">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
  <div class="page-head">
    <div>
      <p class="small muted mb-1"><a href="<?= e(u('projet.php?id=' . $projet_id)) ?>" style="color:var(--blue)">← Retour au projet <?= e(reference_projet_courte($projet['project_reference'], $projet_id)) ?></a></p>
      <h1><?= e(trim($projet['prenom'] . ' ' . $projet['nom'])) ?></h1>
      <p><?= e($projet['titre_pro'] ?: 'Expert Missiona') ?></p>
    </div>
    <span class="badge badge-blue">Profil lié au projet</span>
  </div>
  <div class="grid" style="grid-template-columns:minmax(0,1fr) 300px;gap:24px;align-items:start">
    <div>
      <section class="panel mb-3">
        <div class="panel-body">
          <div class="flex-center mb-2">
            <span class="avatar lg"><?= initiales($projet) ?></span>
            <div><h2><?= e(trim($projet['prenom'] . ' ' . $projet['nom'])) ?></h2><p class="small muted mb-1"><?= e($projet['titre_pro'] ?: 'Expert Missiona') ?></p>
              <p class="small stars mb-0"><?= str_repeat('★',(int)round((float)$projet['note_moyenne'])) ?> <span class="muted"><?= number_format((float)$projet['note_moyenne'],1,',','') ?>/5 · <?= $nb_missions ?> mission<?= $nb_missions===1?'':'s' ?> terminée<?= $nb_missions===1?'':'s' ?></span></p>
            </div>
          </div>
          <?php if (!empty($projet['bio'])): ?><h3>Présentation</h3><p style="white-space:pre-line"><?= e($projet['bio']) ?></p><?php endif; ?>
          <h3>Compétences</h3>
          <?php if ($competences): ?><div class="crit"><?php foreach ($competences as $competence): ?><span><?= e($competence) ?></span><?php endforeach; ?></div>
          <?php else: ?><p class="small muted">Aucune compétence renseignée.</p><?php endif; ?>
          <?php if (!empty($projet['experience'])): ?><p class="small muted mt-2">Expérience : <?= (int)$projet['experience'] ?> an<?= (int)$projet['experience']===1?'':'s' ?></p><?php endif; ?>
        </div>
      </section>
      <section class="panel">
        <div class="panel-head"><h3>Portfolio</h3><span class="badge badge-blue"><?= count($portfolio) ?> réalisation<?= count($portfolio)>1?'s':'' ?></span></div>
        <div class="panel-body">
          <?php if (!$portfolio): ?><div class="empty"><div class="ico">🖼️</div><p>Ce profil ne comporte pas encore de réalisation.</p></div>
          <?php else: ?><div class="pf-grid">
            <?php foreach ($portfolio as $realisation): $caption = $realisation['titre'] ?: 'Réalisation du portfolio'; ?>
              <figure class="pf-card">
                <img src="<?= e(portfolio_image_url($realisation['id'], $projet_id)) ?>" alt="<?= e($caption) ?>" data-portfolio-fullscreen data-portfolio-caption="<?= e($caption) ?>" tabindex="0" role="button" aria-label="Afficher en plein écran : <?= e($caption) ?>" loading="lazy">
                <figcaption><strong><?= e($caption) ?></strong><?php if (!empty($realisation['description'])): ?><span><?= nl2br(e($realisation['description'])) ?></span><?php endif; ?></figcaption>
              </figure>
            <?php endforeach; ?>
          </div><?php endif; ?>
        </div>
      </section>
    </div>
    <aside class="grid" style="gap:24px">
      <section class="panel">
        <div class="panel-head"><h3>Disponibilité & tarifs</h3></div>
        <div class="panel-body">
          <div class="recap">
            <div class="recap-row"><span>Disponibilité</span><strong><?= e(ucfirst((string)$projet['disponibilite'])) ?></strong></div>
            <?php if ((int)$projet['tarif_projet']>0): ?><div class="recap-row"><span>Tarif indicatif</span><strong><?= euros($projet['tarif_projet']) ?></strong></div><?php endif; ?>
          </div>
          <?php if ($forfaits): ?><h4 class="mt-2">Forfaits</h4><?php foreach ($forfaits as $forfait): ?><div class="recap mb-1"><div class="recap-row"><strong><?= e($forfait['nom']) ?></strong><strong><?= euros($forfait['prix']) ?></strong></div><?php if (!empty($forfait['delai'])): ?><p class="small muted mb-0"><?= (int)$forfait['delai'] ?> jour<?= (int)$forfait['delai']===1?'':'s' ?></p><?php endif; ?><?php if (!empty($forfait['description'])): ?><p class="small mb-0"><?= e($forfait['description']) ?></p><?php endif; ?></div><?php endforeach; ?><?php endif; ?>
        </div>
      </section>
      <section class="panel"><div class="panel-head"><h3>Mission concernée</h3></div><div class="panel-body"><strong><?= e($projet['project_title']) ?></strong><p class="small muted mb-0"><?= e(reference_projet_courte($projet['project_reference'], $projet_id)) ?> · <?= e(statut_label($projet['project_status'])) ?></p></div></section>
    </aside>
  </div>
</main>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
