<?php
require_once __DIR__ . '/includes/functions.php';
require_role('admin');

$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare("SELECT p.*, e.societe, e.nom AS e_nom FROM projets p LEFT JOIN users e ON e.id=p.entreprise_id WHERE p.id=?");
$st->execute([$id]);
$projet = $st->fetch();
if (!$projet) { header('Location: ' . u('/admin')); exit; }

// Attribution de la mission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (!peut_gerer_projet($projet)) {
        flash(refus_gestion(), 'error');
        header('Location: ' . u('admin-matching.php?id=' . $id)); exit;
    }
    $fid = (int)($_POST['freelance_id'] ?? 0);
    if ($fid) {
        // Après attribution, l'échéance et éventuellement le PaymentIntent sont
        // liés à l'expert retenu. Une nouvelle affectation ne doit jamais les
        // remplacer silencieusement : annulez/régularisez d'abord la mission.
        if (!empty($projet['freelance_id'])) {
            flash("Cette mission est déjà attribuée. Annulez ou régularisez l'échéance avant de changer d'expert.", 'error');
            header('Location: ' . u('projet.php?id=' . $id)); exit;
        }
        $fs = db()->prepare("SELECT * FROM users WHERE id=? AND role='freelance' AND COALESCE(actif,1)=1 AND COALESCE(compte_supprime,0)=0"); $fs->execute([$fid]); $fl = $fs->fetch();
        $deja_retire = false;
        if ($fl) {
            $ex = db()->prepare("SELECT 1 FROM projet_freelance_exclus WHERE projet_id=? AND freelance_id=? LIMIT 1");
            $ex->execute([$id,$fid]);
            $deja_retire = (bool)$ex->fetchColumn();
        }
        if (!$fl || $deja_retire) {
            flash($deja_retire ? "Cet expert a déjà été retiré de ce projet; choisissez un autre profil." : "Expert introuvable ou inactif.", 'error');
            header('Location: ' . u('admin-matching.php?id=' . $id)); exit;
        }

        // La rémunération est arrêtée à l'attribution, mais aucune échéance
        // n'est créée ni débitée avant la validation finale du livrable.
        $base = tarif_reference($fl) ?: (int) round(($projet['budget_min'] + $projet['budget_max']) / 2);
        db()->prepare("UPDATE projets SET freelance_id=?, statut='attribue', avancement=5,
                       montant_final=?, paiement_fin_livraison=1, livrable_accepte_le='', livrable_accepte_par=0
                       WHERE id=?")
            ->execute([$fid, $base, $id]);

        notify($fid, "Nouvelle mission attribuée : « ".$projet['titre']." ». Le client pourra consulter votre profil et accepter la proposition; le paiement interviendra après validation du livrable.", 'projet.php?id='.$id);
        notify($projet['entreprise_id'], "Un expert a été sélectionné pour votre projet « ".$projet['titre']." ». Consultez son profil puis validez la proposition pour lancer la mission; aucun paiement n'est demandé avant l'acceptation du livrable.", 'projet.php?id='.$id);
        db()->prepare("INSERT INTO messages (projet_id,expediteur_id,destinataire_id,contenu) VALUES (?,1,?,?)")
            ->execute([$id, $projet['entreprise_id'],
              "Bonne nouvelle : nous avons sélectionné l'expert pour votre projet « ".$projet['titre']." ». Consultez son profil et validez sa proposition depuis le détail du projet pour lancer la mission. Aucun paiement ne sera demandé avant que vous acceptiez le livrable."]);
        db()->prepare("INSERT INTO messages (projet_id,expediteur_id,destinataire_id,contenu) VALUES (?,1,?,?)")
            ->execute([$id, $fid,
              "Bonjour ".($fl['prenom'] ?: $fl['nom']).", nous vous attribuons la mission « ".$projet['titre']." ». Le cahier des charges est disponible dans le détail du projet. Le paiement interviendra après validation du livrable par le client. Je reste votre interlocuteur unique."]);
        flash("Mission attribuée avec succès à ".trim($fl['prenom'].' '.$fl['nom']).".");
        header('Location: ' . u('projet.php?id=' . $id)); exit;
    }
}

$resultats = calculer_matching($projet);
$coefs = [
  'competences' => (int)param('coef_competences',40),
  'budget'      => (int)param('coef_budget',25),
  'dispo'       => (int)param('coef_dispo',15),
  'experience'  => (int)param('coef_experience',10),
  'note'        => (int)param('coef_note',10),
];
$labels = ['competences'=>'Compétences','budget'=>'Budget','dispo'=>'Disponibilité','experience'=>'Expérience','note'=>'Note'];

if (isset($_GET['live_refresh'])) {
    ob_start();
    require __DIR__ . '/includes/admin-matching-results.php';
    $html = (string) ob_get_clean();
  $htmlStable = preg_replace('/name="csrf" value="[^"]*"/', 'name="csrf" value=""', $html);
  $htmlStable = preg_replace('/([?&])expires=\d+&sig=[a-f0-9]+/', '$1expires=0&sig=stable', (string) $htmlStable);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private, max-age=0');
    header('X-Content-Type-Options: nosniff');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    echo json_encode([
        'ok' => true,
        'revision' => hash('sha256', (string) $htmlStable),
        'html' => $html,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

$titre = "Matching";
require_once __DIR__ . '/includes/header.php';
?>
<div class="app">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">

  <div class="page-head">
    <div>
      <p class="small muted mb-1"><a href="/admin" style="color:var(--blue)">← Retour au back-office</a></p>
      <h1>Matching — <?= e(reference_projet_courte($projet['reference'] ?? '', $id)) ?> · <?= e($projet['titre']) ?></h1>
      <p>Classement des experts selon les critères mesurables configurés.</p>
    </div>
    <?php if (est_admin_principal()): ?><a href="/admin-parametres" class="btn btn-ghost">Ajuster les coefficients</a><?php endif; ?>
  </div>

  <div class="grid" style="grid-template-columns:1fr 320px;gap:24px;align-items:start">

    <div class="panel" id="matchingResults">
      <?php require __DIR__ . '/includes/admin-matching-results.php'; ?>
    </div>

    <div class="grid" style="gap:24px">
      <div class="panel">
        <div class="panel-head"><h3>Le projet</h3></div>
        <div class="panel-body">
          <div class="recap">
            <div class="recap-row"><span>Client</span><strong><?= e($projet['societe']) ?></strong></div>
            <div class="recap-row"><span>Catégorie</span><strong><?= e($projet['categorie']) ?></strong></div>
            <div class="recap-row"><span>Budget</span><strong><?= euros($projet['budget_min']) ?> – <?= euros_max($projet['budget_max']) ?></strong></div>
            <div class="recap-row"><span>Délai</span><strong><?= e($projet['delai']) ?></strong></div>
            <div class="recap-row"><span>Échéance</span><strong><?= date_fr($projet['date_limite']) ?></strong></div>
            <div class="recap-row"><span>Statut</span><strong><span class="badge <?= statut_classe($projet['statut']) ?>"><?= statut_label($projet['statut']) ?></span></strong></div>
          </div>
          <h4 class="mt-3 mb-1" style="font-size:.8125rem;text-transform:uppercase;color:var(--muted)">Compétences requises</h4>
          <div class="crit">
            <?php foreach (array_filter(array_map('trim', explode(',', $projet['competences']))) as $c): ?>
              <span><?= e($c) ?></span>
            <?php endforeach; ?>
          </div>
          <h4 class="mt-3 mb-1" style="font-size:.8125rem;text-transform:uppercase;color:var(--muted)">Description</h4>
          <p class="small"><?= nl2br(e($projet['description'])) ?></p>
        </div>
      </div>

      <div class="panel">
        <div class="panel-head"><h3>Coefficients appliqués</h3></div>
        <div class="panel-body">
          <?php foreach ($labels as $k => $lab): ?>
            <div class="flex-between mb-1" style="font-size:.875rem">
              <span><?= $lab ?></span><strong><?= $coefs[$k] ?> %</strong>
            </div>
          <?php endforeach; ?>
          <?php if (est_admin_principal()): ?><a href="/admin-parametres" class="btn btn-ghost btn-block mt-3 btn-sm">Modifier</a><?php endif; ?>
        </div>
      </div>
    </div>

  </div>
</main>
</div>
<script src="<?= e(asset('assets/js/admin-matching-live.js')) ?>" defer></script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
