/* ==========================================================================
   PANNACOTTACLUB — carte de la plage, verrouillée du poste 1 au poste 2
   --------------------------------------------------------------------------
   Refonte complète de la cartographie (octobre 2026) :

   · La carte est BLOQUÉE sur la bande de plage entre les deux postes de
     secours (coordonnées exactes ci-dessous) : impossible de la déplacer
     ou de dézoomer au-delà. En ouvrant l'écran, on voit TOUTE la bande,
     la MER au nord, les deux postes — et en 2 secondes on sait où on est.
   · Épingles parlantes avec étiquette permanente : « VOUS » (rond bleu qui
     pulse) et « LIVREUR » (rond orange). Un trait pointillé relie les deux
     avec la distance écrite au milieu. Aucun appui nécessaire pour comprendre.
   · Fond de carte 100 % hébergé dans le site (extrait OpenStreetMap recadré
     exactement sur la bande : assets/map/cabourg.json) — léger, instantané,
     aucune requête externe (conforme à la sécurité de l'hébergeur), et il
     fonctionne même sans réseau. Rendu en toile (Canvas) pour la fluidité.

   Repères géographiques exacts du club :
     · Poste de secours 1 : 49.289616, -0.139386
     · Poste de secours 2 : 49°17'29.8"N 0°07'43.1"W  (49.291611, -0.128639)
   ========================================================================== */
import { distanceLabel, BASE } from './core.js';

/* Ouvre l'application de cartes du téléphone (itinéraire). */
export const mapsLink = (pos) =>
  `https://www.google.com/maps/dir/?api=1&destination=${pos.lat},${pos.lng}&travelmode=walking`;

export const geoLink = (pos) => `geo:${pos.lat},${pos.lng}?q=${pos.lat},${pos.lng}`;

/* ------------------------------------------------------- repères exacts */
const POSTE1 = { lat: 49.289616, lng: -0.139386 };
const POSTE2 = { lat: 49.291611, lng: -0.128639 };   /* 49°17'29.8"N 0°07'43.1"W */
const MILIEU = { lat: (POSTE1.lat + POSTE2.lat) / 2, lng: (POSTE1.lng + POSTE2.lng) / 2 };

/* Le cadre dans lequel la carte est verrouillée : d'un poste à l'autre,
   plus une marge confortable — un bout de mer au nord (pour l'horizon),
   la promenade et les premières rues au sud (pour se repérer), et un peu
   de sable au-delà de chaque poste. */
const M_PAR_DEG_LAT = 111320;
const M_PAR_DEG_LNG = 111320 * Math.cos((MILIEU.lat * Math.PI) / 180);
const MARGE = { ouest: 160, est: 160, nord: 170, sud: 230 };   /* mètres */
const CADRE = {
  sud: Math.min(POSTE1.lat, POSTE2.lat) - MARGE.sud / M_PAR_DEG_LAT,
  nord: Math.max(POSTE1.lat, POSTE2.lat) + MARGE.nord / M_PAR_DEG_LAT,
  ouest: Math.min(POSTE1.lng, POSTE2.lng) - MARGE.ouest / M_PAR_DEG_LNG,
  est: Math.max(POSTE1.lng, POSTE2.lng) + MARGE.est / M_PAR_DEG_LNG,
};

/* Les 11 accès/escaliers de la digue, répartis régulièrement entre le
   poste 1 (sud-ouest) et le poste 2 (nord-est), le long de la promenade
   Marcel Proust. Chaque panneau QR porte ce numéro : quand un client le
   scanne, le site sait immédiatement où il se trouve — sans GPS. */
export const ACCES_DIGUE = Array.from({ length: 11 }, (_, i) => {
  const f = i / 10;
  return {
    n: i + 1,
    lat: Number((POSTE1.lat + (POSTE2.lat - POSTE1.lat) * f).toFixed(6)),
    lng: Number((POSTE1.lng + (POSTE2.lng - POSTE1.lng) * f).toFixed(6)),
  };
});
const RAYON_PAR_DEFAUT = 700;   /* mètres : couvre les deux postes + le sable */

let CONFIG = { zone: null };

/** Conservé pour compatibilité avec app.js (zone transmise par /api/config). */
export function configureMap({ zone = null } = {}) {
  CONFIG = { zone: zone || null };
  return CONFIG;
}

const nb = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);

/** Distance à vol d'oiseau en mètres entre deux positions. */
function distanceM(a, b) {
  const R = 6371000;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2
    + Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Échappe le texte des étiquettes (noms de livreurs…). */
const html = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[c]));

/* ------------------------------------------------------ chargement Leaflet */
let promesseLeaflet = null;

function chargerLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  if (!promesseLeaflet) {
    promesseLeaflet = new Promise((resoudre, rejeter) => {
      const css = document.createElement('link');
      css.rel = 'stylesheet';
      css.href = `${BASE}assets/vendor/leaflet/leaflet.css`;
      document.head.appendChild(css);
      const script = document.createElement('script');
      script.src = `${BASE}assets/vendor/leaflet/leaflet.js`;
      script.onload = () => (window.L ? resoudre(window.L) : rejeter(new Error('leaflet-absent')));
      script.onerror = () => { promesseLeaflet = null; rejeter(new Error('leaflet-injoignable')); };
      document.head.appendChild(script);
      setTimeout(() => { if (window.L) resoudre(window.L); }, 8000);
    });
  }
  return promesseLeaflet;
}

/* ============================================================== création === */
/**
 * Crée la carte dans le conteneur.
 * @param {HTMLElement} el conteneur (.map)
 * @param {{center?:{lat,lng}, zoom?:number, zone?:object,
 *          nomClient?:string, nomLivreur?:string}} options
 *   nomClient / nomLivreur : étiquette écrite sous les épingles
 *   (défauts : « CLIENT » / « LIVREUR » ; l'écran client passe « VOUS »,
 *   l'écran livreur passe « MOI » pour sa propre épingle).
 */
export function createMap(el, { center = null, zoom = 15, zone = null, nomClient = 'CLIENT', nomLivreur = 'LIVREUR', liaison = false } = {}) {
  if (!el) return null;

  const laZone = zone || CONFIG.zone || null;
  const centreZone = (nb(laZone?.lat) != null && nb(laZone?.lng) != null)
    ? { lat: Number(laZone.lat), lng: Number(laZone.lng) }
    : MILIEU;
  const rayonZone = nb(laZone?.radius) || RAYON_PAR_DEFAUT;

  const etat = {
    el, mode: 'osm', pret: false, erreur: '', client: null, livreur: null,
    livreurs: new Map(), destruction: false, maj: 0, minuteur: null,
    carte: null, suivre: true, cadreLL: null, ligne: null, distMarqueur: null, liaison: !!liaison,
  };

  /* La légende éventuellement déjà présente (« Vous / Votre livreur ») est
     conservée et reposée par-dessus la carte. */
  const dejaLa = [...el.children];
  el.classList.add('pcmap', 'pcosm');
  el.innerHTML = `
    <div class="pcosm-cadre">
      <div class="pcosm-canvas"></div>
      <div class="pcmap-charge">Chargement du plan…</div>
    </div>
    <div class="pcmap-controles">
      <button type="button" class="pcmap-btn" data-zoom="1" aria-label="Zoomer">+</button>
      <button type="button" class="pcmap-btn" data-zoom="-1" aria-label="Dézoomer">−</button>
      <button type="button" class="pcmap-btn pcmap-btn-large" data-action="fit" aria-label="Tout afficher" title="Tout afficher">⤢</button>
      <button type="button" class="pcmap-btn pcmap-btn-large" data-action="suivre" aria-label="Suivre le livreur" title="Recentrer sur le livreur">🎯</button>
    </div>
    <div class="pcmap-bandeau">
      <span class="pcmap-etat">Chargement de la carte…</span>
      <a class="pcmap-lien" data-role="position" href="#" target="_blank" rel="noopener">Position</a>
      <a class="pcmap-lien" data-role="itineraire" href="#" target="_blank" rel="noopener" hidden>Itinéraire</a>
    </div>`;
  const cadreEl = el.querySelector('.pcosm-cadre');
  for (const node of dejaLa) cadreEl.appendChild(node);   /* légende conservée */

  const etatEl = el.querySelector('.pcmap-etat');
  const chargeEl = el.querySelector('.pcmap-charge');
  const lienEl = el.querySelector('[data-role="position"]');
  const lienItineraire = el.querySelector('[data-role="itineraire"]');

  /* ------------------------------------------------------------- épingles */
  /* Rond coloré avec lettre + étiquette nominative dessous : lisible en
     plein soleil, compréhensible en 2 secondes. */
  const iconeActeur = (L, lettre, classe, etiquette) => L.divIcon({
    className: 'pcmarker pcsuite',
    html: `<span class="pcpin ${classe}"><span class="pcpin-rond">${lettre}</span><span class="pcpin-tag">${html(etiquette)}</span></span>`,
    iconSize: [92, 58], iconAnchor: [46, 17],
  });
  const iconePoste = (L, num) => L.divIcon({
    className: 'pcmarker',
    html: `<span class="pcposte-pt">${num}</span>`,
    iconSize: [26, 26], iconAnchor: [13, 13],
  });

  /* --------------------------------------------------------------- démarrage */
  chargerLeaflet().then((L) => {
    if (etat.destruction) return;
    const cadreLL = L.latLngBounds([CADRE.sud, CADRE.ouest], [CADRE.nord, CADRE.est]);
    etat.cadreLL = cadreLL;

    const carte = L.map(el.querySelector('.pcosm-canvas'), {
      zoomControl: false,              /* nos propres boutons, plus jolis */
      attributionControl: true,
      scrollWheelZoom: !L.Browser.touch,   /* molette sur PC, pas de zoom accidentel au doigt */
      tap: true,
      preferCanvas: true,              /* fond dessiné en toile : fluide sur téléphone */
      maxBounds: cadreLL,              /* ← la carte est bloquée entre les deux postes */
      maxBoundsViscosity: 1.0,         /* mur franc : aucun dépassement élastique */
      maxZoom: 19,
    });

    etat.carte = carte;
    etat.L = L;

    /* Zoom minimum « toute la bande visible » + cadrage initial complet. */
    const sz = carte.getSize();
    if (sz.x > 0 && sz.y > 0) { zoomMini(); carte.fitBounds(cadreLL); }
    else carte.setView([MILIEU.lat, MILIEU.lng], 15);
    carte.on('resize', zoomMini);

    /* Fond de carte ENTIÈREMENT hébergé dans le site (assets/map/cabourg.json,
       véritable extrait d'OpenStreetMap recadré sur la bande : mer, plage,
       rues, bâtiments). Aucune requête externe : conforme à la sécurité de
       l'hébergeur (CSP) et ça fonctionne même sans réseau, sur le sable. */
    carte.attributionControl.addAttribution('Données © OpenStreetMap');
    fetch(`${BASE}assets/map/cabourg.json`).then((r) => r.json()).then((geo) => {
      if (etat.destruction || !etat.carte) return;
      /* Palette « vraie carte » : terre chaude en fond (voir .pcosm en CSS),
         bâtiments beige-gris, rues blanches bordées d'un liseré sable
         (les « casing »), promenade crème le long du sable. */
      const STYLES = {
        mer:      { fillColor: '#A9CFF2', fillOpacity: 1, color: '#86B8E8', weight: 1.2 },
        eau:      { fillColor: '#A9CFF2', fillOpacity: 1, stroke: false },
        plage:    { fillColor: '#F6E7BF', fillOpacity: 1, color: '#EBD9A6', weight: 1 },
        vert:     { fillColor: '#C9E6BC', fillOpacity: 1, stroke: false },
        batiment: { fillColor: '#DED6C3', fillOpacity: 1, color: '#C6BCA2', weight: 0.8 },
        casing1:  { color: '#D9D2BF', weight: 7.4, lineCap: 'round', lineJoin: 'round' },
        casing2:  { color: '#DDD7C6', weight: 5.8, lineCap: 'round', lineJoin: 'round' },
        casing3:  { color: '#E1DBC9', weight: 4, lineCap: 'round', lineJoin: 'round' },
        casingP:  { color: '#E7D9AC', weight: 8, lineCap: 'round', lineJoin: 'round' },
        route1:   { color: '#FFFFFF', weight: 5, lineCap: 'round', lineJoin: 'round' },
        route2:   { color: '#FFFFFF', weight: 3.6, lineCap: 'round', lineJoin: 'round' },
        route3:   { color: '#FFFFFF', weight: 2.4, lineCap: 'round', lineJoin: 'round' },
        promenade:{ color: '#FFF3D6', weight: 5.4, lineCap: 'round', lineJoin: 'round' },
        chemin:   { color: '#FFFFFF', weight: 2, opacity: .95, dashArray: '1 5', lineCap: 'round' },
      };
      L.geoJSON(geo, {
        interactive: false,
        smoothFactor: 0.6,
        style: (f) => STYLES[f.properties?.kind] || STYLES.vert,
      }).addTo(carte);

      /* Noms des rues : la promenade dès la vue d'ensemble, les autres
         rues quand on zoome un peu (sinon ça surcharge). */
      const groupesRue = {};
      for (const e of (geo.etiquettes || [])) {
        const g = groupesRue[e.z] || (groupesRue[e.z] = L.layerGroup());
        L.marker([e.lat, e.lng], {
          interactive: false, keyboard: false, zIndexOffset: 60,
          icon: L.divIcon({
            className: 'pcrue' + (e.c === 'prom' ? ' prom' : ''),
            html: `<span>${html(e.t)}</span>`, iconSize: [180, 14], iconAnchor: [90, 7],
          }),
        }).addTo(g);
      }
      const majEtiquettes = () => {
        const z = carte.getZoom();
        for (const [seuil, g] of Object.entries(groupesRue)) {
          if (z >= Number(seuil)) { if (!carte.hasLayer(g)) g.addTo(carte); }
          else if (carte.hasLayer(g)) carte.removeLayer(g);
        }
      };
      carte.on('zoomend', majEtiquettes);
      majEtiquettes();
      etat.etiquettesMaj = majEtiquettes;
      etat.fond = true;
    }).catch(() => {
      if (!etat.destruction && etatEl) etatEl.textContent = 'Plan détaillé indisponible — épingles et zone affichées.';
    });

    /* Zone de livraison : cercle bleu (réglage du site). */
    L.circle([centreZone.lat, centreZone.lng], {
      radius: rayonZone,
      color: '#060CD4', weight: 1.6, opacity: 0.5, dashArray: '5 6', fillColor: '#060CD4', fillOpacity: 0.05,
    }).addTo(carte);

    /* Le mot « MER », écrit dans l'eau au nord : l'orientation est immédiate. */
    L.marker([CADRE.nord - 55 / M_PAR_DEG_LAT, MILIEU.lng], {
      interactive: false, keyboard: false, zIndexOffset: 10,
      icon: L.divIcon({ className: 'pcmer', html: '<span>MER</span>', iconSize: [140, 22], iconAnchor: [70, 11] }),
    }).addTo(carte);

    /* Les deux postes de secours, positions exactes, toujours visibles :
       ce sont les bornes de la carte. */
    for (const [num, p] of [['1', POSTE1], ['2', POSTE2]]) {
      L.marker([p.lat, p.lng], { icon: iconePoste(L, num), zIndexOffset: 100 })
        .addTo(carte)
        .bindTooltip(`Poste de secours ${num}`, {
          /* Au-dessus (côté sable) : en dessous, l'étiquette écraserait
             celles des épingles VOUS/LIVREUR quand on est près d'un poste. */
          permanent: true, direction: 'top', offset: [0, -14], className: 'pcposte-tip',
        });
    }

    etat.pret = true;
    chargeEl.hidden = true;
    carte.on('dragstart zoomstart', () => { etat.suivre = false; });
    el.querySelector('[data-action="suivre"]').addEventListener('click', () => {
      etat.suivre = true;
      const cible = etat.livreur || etat.client || MILIEU;
      carte.setView([cible.lat, cible.lng], Math.max(carte.getZoom(), 16), { animate: true });
    });
    peindre();
    cadrer();
  }).catch((err) => {
    etat.erreur = String(err.message || err);
    chargeEl.textContent = 'Carte indisponible (hors connexion).';
    etatEl.textContent = 'Carte indisponible hors connexion — position exacte ci-dessous.';
    if (etat.livreur || etat.client) lienEl.href = mapsLink(etat.livreur || etat.client);
  });

  /* Le dézoom maximum = exactement la bande entière, quelle que soit la
     taille de l'écran (recalculé si la fenêtre change de taille). */
  function zoomMini() {
    if (!etat.carte || !etat.cadreLL) return;
    const sz = etat.carte.getSize();
    if (!sz.x || !sz.y) return;
    const z = etat.carte.getBoundsZoom(etat.cadreLL, false);
    if (Number.isFinite(z)) etat.carte.setMinZoom(z);
  }

  /* ------------------------------------------------------------- épingles */
  const poserOuBouger = (cle, pos, { lettre, classe, etiquette }) => {
    const L = etat.L;
    if (!L || !etat.carte) return;
    const q = [Number(pos.lat), Number(pos.lng)];
    if (!etat.epingles) etat.epingles = new Map();
    let m = etat.epingles.get(cle);
    if (!m) {
      m = L.marker(q, {
        icon: iconeActeur(L, lettre, classe, etiquette),
        title: etiquette || '',
        zIndexOffset: 500, keyboard: false,
      }).addTo(etat.carte);
      m._etiquette = etiquette;
      etat.epingles.set(cle, m);
    } else {
      if (m._etiquette !== etiquette) {   /* le nom du livreur est arrivé après coup */
        m.setIcon(iconeActeur(L, lettre, classe, etiquette));
        m._etiquette = etiquette;
      }
      m.setLatLng(q);           /* la classe .pcsuite anime le glissement */
    }
  };

  const retirer = (cle) => {
    const m = etat.epingles?.get(cle);
    if (m) { etat.carte.removeLayer(m); etat.epingles.delete(cle); }
  };

  /* Trait pointillé livreur ↔ client + distance écrite au milieu :
     d'un coup d'œil, on voit qui est où et à combien de mètres. Réservé
     aux écrans d'une seule course (suivi client, tableau livreur) qui
     demandent l'option « liaison » — sinon on relierait de mauvaises
     personnes sur la carte d'ensemble de l'admin. */
  function peindreLiaison() {
    const L = etat.L;
    const c = etat.client;
    const l = etat.liaison ? etat.livreur : null;
    if (!L || !etat.carte) return;
    if (!c || !l) {
      if (etat.ligne) { etat.carte.removeLayer(etat.ligne); etat.ligne = null; }
      if (etat.distMarqueur) { etat.carte.removeLayer(etat.distMarqueur); etat.distMarqueur = null; }
      return;
    }
    const a = [l.lat, l.lng];
    const b = [c.lat, c.lng];
    if (!etat.ligne) {
      etat.ligne = L.polyline([a, b], {
        color: '#060CD4', weight: 3, opacity: 0.85, dashArray: '2 7', lineCap: 'round', interactive: false,
      }).addTo(etat.carte);
    } else etat.ligne.setLatLngs([a, b]);
    const milieuLigne = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    const texte = distanceLabel(distanceM(l, c));
    if (!etat.distMarqueur) {
      etat.distMarqueur = L.marker(milieuLigne, {
        interactive: false, keyboard: false, zIndexOffset: 400,
        icon: L.divIcon({ className: 'pcmarker', html: `<span class="pcdist">${html(texte)}</span>`, iconSize: [76, 24], iconAnchor: [38, 12] }),
      }).addTo(etat.carte);
    } else {
      etat.distMarqueur.setLatLng(milieuLigne);
      const elDist = etat.distMarqueur.getElement()?.querySelector('.pcdist');
      if (elDist && elDist.textContent !== texte) elDist.textContent = texte;
    }
  }

  /* --------------------------------------------------------------- bandeau */
  const ilYA = (ms) => {
    const sec = Math.round((Date.now() - ms) / 1000);
    if (sec < 5) return "à l'instant";
    if (sec < 60) return `il y a ${sec} s`;
    return `il y a ${Math.round(sec / 60)} min`;
  };

  function majBandeau() {
    const l = etat.livreur;
    const c = etat.client;
    const bouts = [];
    if (l && c) bouts.push(`Livreur à ${distanceLabel(distanceM(l, c))}`);
    const ref = l || c;
    if (ref) {
      bouts.push(`position exacte ${ref.lat.toFixed(5)}, ${ref.lng.toFixed(5)}`);
      if (ref.at) bouts.push(`relevée ${ilYA(ref.at)}`);
      if (nb(ref.accuracy) && Number(ref.accuracy) > 0) bouts.push(`précision ± ${Math.round(ref.accuracy)} m`);
    } else {
      bouts.push('Plage de Cabourg — du poste 1 au poste 2');
    }
    etatEl.textContent = bouts.join(' · ');
  }

  function peindre() {
    majBandeau();
    if (!etat.carte) return;
    if (etat.client) poserOuBouger('client', etat.client, { lettre: 'V', classe: 'pcpin--vous', etiquette: nomClient });
    else retirer('client');
    for (const [id, l] of etat.livreurs) {
      const etiquette = nomLivreur === 'MOI' ? 'MOI' : (l.nom || nomLivreur);
      poserOuBouger(`livreur:${id}`, l, { lettre: 'L', classe: 'pcpin--liv', etiquette });
    }
    for (const cle of [...(etat.epingles?.keys() || [])]) {
      if (cle.startsWith('livreur:') && !etat.livreurs.has(cle.slice(8))) retirer(cle);
    }
    peindreLiaison();
    /* La carte suit la course : si le livreur sort du cadre, on le ramène doucement. */
    if (etat.suivre && etat.livreur && etat.carte) {
      const b = etat.carte.getBounds().pad(-0.12);
      const p = etat.livreur;
      if (!b.contains([p.lat, p.lng])) {
        etat.carte.panTo([p.lat, p.lng], { animate: true, duration: 0.8 });
      }
    }
    const c = etat.client;
    lienItineraire.hidden = !(c && etat.livreur);
    if (c && etat.livreur) {
      lienItineraire.href = `https://www.google.com/maps/dir/?api=1&origin=${etat.livreur.lat},${etat.livreur.lng}&destination=${c.lat},${c.lng}&travelmode=walking`;
    }
    const ref = etat.livreur || etat.client;
    if (ref) lienEl.href = mapsLink(ref);
  }

  /* « Tout afficher » : les acteurs ET les deux bornes de la plage —
     toujours dans les limites du cadre verrouillé. */
  function cadrer() {
    if (!etat.carte || !etat.cadreLL) return;
    const sz = etat.carte.getSize();
    if (!sz.x || !sz.y) return;
    const L = etat.L;
    const points = [etat.client, ...etat.livreurs.values(), POSTE1, POSTE2].filter(Boolean);
    etat.carte.fitBounds(L.latLngBounds(points.map((p) => [p.lat, p.lng])), { padding: [36, 36], maxZoom: 17 });
  }

  /* -------------------------------------------------------------- contrôles */
  const bouton = (sel, fn) => el.querySelector(sel)?.addEventListener('click', fn);
  bouton('[data-zoom="1"]', () => etat.carte?.zoomIn());
  bouton('[data-zoom="-1"]', () => etat.carte?.zoomOut());
  bouton('[data-action="fit"]', () => cadrer());

  /* ------------------------------------------------------------------- API */
  const api = {
    el,
    state: etat,
    setClient(pos) {
      const p = pos && nb(pos.lat) != null ? { lat: Number(pos.lat), lng: Number(pos.lng) } : null;
      if (!p || etat.destruction) return;
      etat.client = { ...p, accuracy: Number(pos.accuracy) || 0, at: pos.at || Date.now(), titre: 'Client' };
      etat.maj++;
      peindre();
    },
    setCourier(pos, { id = 'defaut', nom = '' } = {}) {
      const p = pos && nb(pos.lat) != null ? { lat: Number(pos.lat), lng: Number(pos.lng) } : null;
      if (!p || etat.destruction) return;
      const fiche = { ...p, accuracy: Number(pos.accuracy) || 0, at: pos.at || Date.now(), nom: nom || '', titre: nom ? `Livreur ${nom}` : 'Livreur' };
      /* Le suivi pose d'abord le livreur sans identifiant, puis avec :
         on remplace la fiche temporaire pour ne pas compter deux livreurs. */
      if (id !== 'defaut') etat.livreurs.delete('defaut');
      etat.livreurs.set(id, fiche);
      etat.livreur = fiche;                  /* le dernier reçu = celui du suivi */
      etat.maj++;
      peindre();
    },
    clearCourier() {
      if (etat.destruction) return;
      etat.livreur = null;
      etat.livreurs.clear();
      etat.maj++;
      peindre();
    },
    fit() { cadrer(); },
    invalidate() {
      setTimeout(() => { etat.carte?.invalidateSize(); zoomMini(); }, 120);
    },
    info() {
      return {
        mode: 'osm', pret: etat.pret, erreur: etat.erreur, source: 'openstreetmap-leaflet',
        client: etat.client ? `${etat.client.lat},${etat.client.lng}` : null,
        livreur: etat.livreur ? `${etat.livreur.lat},${etat.livreur.lng}` : null,
        livreurs: etat.livreurs.size, maj: etat.maj,
      };
    },
    destroy() {
      etat.destruction = true;
      clearInterval(etat.minuteur);
      if (etat.carte) { etat.carte.remove(); etat.carte = null; }
      el.innerHTML = '';
      el.classList.remove('pcmap', 'pcosm');
    },
  };

  /* Le bandeau se rafraîchit tout seul (« relevée il y a 3 s »). */
  etat.minuteur = setInterval(() => { if (!etat.destruction) majBandeau(); }, 4000);
  window.addEventListener('pagehide', () => clearInterval(etat.minuteur), { once: true });

  return api;
}

/* ------------------------------------------------------------ utilitaires */
/** Texte lisible : distance entre le livreur et le client. */
export function routeText(courier, client) {
  if (!courier || !client) return '';
  return `${distanceLabel(distanceM(courier, client))} de vous`;
}
