/* Neutralise le script de preview ; aucune interface de demonstration sur le site. */
