/* Handler Web Push prêt pour une intégration serveur VAPID. La preview ne peut pas envoyer de push. */
self.addEventListener('push', (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (e) { data = { body: event.data ? event.data.text() : '' }; }
  const title = data.title || 'Un message de Sève';
  const options = {
    body: data.body || 'Votre fil est disponible. Ouvrez Sève quand vous le souhaitez.',
    tag: 'seve-weekly-reminder',
    renotify: false,
    data: { url: data.url || '/#/app/team' }
  };
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = new URL(event.notification.data && event.notification.data.url || '/#/app/team', self.location.origin).href;
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
    const existing = clients.find((client) => client.url.startsWith(self.location.origin));
    if (existing) { existing.navigate(target); return existing.focus(); }
    return self.clients.openWindow(target);
  }));
});
