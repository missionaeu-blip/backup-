/* Version refuge : un seul parcours, libre et gratuit, sans effacer le site
   historique ni les comptes. Messages de la maquette = locaux au navigateur. */
(function () {
  const U = SEVE.util, ui = SEVE.ui, store = SEVE.store, icon = SEVE.icons.svg;
  const topics = [
    { id: 'fatigue', label: 'Fatigue', glyph: '🌿', text: 'Vous pouvez ralentir. Votre rythme n’a pas à être justifié.' },
    { id: 'confiance', label: 'Confiance', glyph: '✨', text: 'Un doute ne définit pas votre valeur. Parlons-en sans vous presser.' },
    { id: 'question', label: 'Questions', glyph: '💬', text: 'Même si vous ne savez pas comment formuler, nous pouvons commencer par une phrase.' },
    { id: 'juridique', label: 'Droits & démarches', glyph: '⚖️', text: 'Nous pouvons vous aider à poser vos questions ; ceci ne remplace pas un avis d’avocat.' }
  ];
  const esc = U.esc;
  function nom() { const p = store.me(); return p ? String(p.name || '').split(' ')[0] : ''; }
  function liens() {
    return '<a href="#/app">Mon espace</a><a href="#/app/resources">Mes ressources</a><a href="#/app/team">Écrire</a>';
  }
  SEVE.views.refugeShell = function (ctx) {
    const user = store.currentUser();
    return '<div class="refuge-shell"><header class="refuge-nav"><a href="#/" class="refuge-logo" aria-label="Sève, accueil">' +
      '<span class="refuge-logo__icone">' + icon('heartFill', 18) + '</span><b>Sève<span class="refuge-logo__point">.</span></b></a>' +
      '<nav aria-label="Navigation principale">' + (user ? liens() : '<a href="#/">Accueil</a><a href="#/login">Se connecter</a>') + '</nav>' +
      (user ? '<button type="button" data-act="refuge-sortir" class="refuge-logout">Se déconnecter</button>' :
        '<a href="#/signup" class="refuge-cta">Créer un compte</a>') +
      '</header><main id="view" class="refuge-main" tabindex="-1"></main>' +
      '<footer class="refuge-footer"><span>Sève · <a href="#/mentions-legales">Mentions légales</a> · <a href="#/politique-confidentialite">Confidentialité</a> · <a href="#/cgu">CGU</a> · <a href="#/financement">Financement</a></span>' +
      '<span>En cas de danger immédiat : 17 ou 112. Signaler : <a href="mailto:missiona.eu@gmail.com?subject=Signalement%20S%C3%A8ve">missiona.eu@gmail.com</a></span></footer></div>';
  };
  SEVE.views.refugeView = function (ctx) {
    if (ctx.path === '/admin/connexion') return 'adminConnexion';
    if (ctx.path === '/login') return 'refugeLogin';
    if (ctx.path === '/signup') return 'refugeSignup';
    if (ctx.path === '/app/team') return 'refugeTalk';
    if (ctx.path === '/app/resources') return 'refugeResources';
    if (ctx.path === '/app/care') return 'refugePause';
    if (ctx.path.startsWith('/app')) return 'refugeDashboard';
    if (ctx.path.startsWith('/legal/') || ['/mentions-legales','/politique-confidentialite','/cgu','/financement'].includes(ctx.path)) return 'legal';
    if (ctx.path === '/avant-ouverture' || ctx.path === '/register') return 'avantOuverture';
    return 'refugeHome';
  };
  function head(kicker, title, subtitle) {
    return '<div class="refuge-head"><span class="refuge-kicker">' + esc(kicker) + '</span><h1>' + title + '</h1><p>' + subtitle + '</p></div>';
  }
  function topicCards() {
    return '<div class="refuge-topics">' + topics.map((t) =>
      '<a class="refuge-topic" href="#/app/team?topic=' + t.id + '"><span aria-hidden="true">' + t.glyph + '</span><b>' + t.label +
      '</b><small>' + t.text + '</small><em>En parler →</em></a>').join('') + '</div>';
  }
  SEVE.views.refugeHome = { title: 'Bienvenue', render() {
    return '<section class="refuge-hero refuge-hero--editorial"><div class="refuge-hero__copy">' +
      '<span class="refuge-audience-badge">Pour les créatrices de contenu adulte 18+</span>' +
      '<h1>Vous avez le droit de <i>souffler.</i></h1>' +
      '<p>Il y a des jours où créer, répondre, négocier et tout porter devient trop lourd. Ici, vous pouvez poser ce qui vous traverse, retrouver des repères et avancer à votre rythme. Aucune performance à prouver.</p>' +
      '<div class="refuge-hero__actions"><a class="refuge-cta refuge-cta--large" href="#/signup">Créer mon compte →</a><a class="refuge-cta refuge-cta--light" href="#/login">J’ai déjà un compte</a></div>' +
      '<span class="refuge-hint">Service gratuit · images privées après vérification et modération · aucun paiement demandé.</span></div>' +
      '<div class="refuge-hero__art" aria-hidden="true"><div class="refuge-art__sun"></div><div class="refuge-art__petal refuge-art__petal--a"></div><div class="refuge-art__petal refuge-art__petal--b"></div><div class="refuge-art__petal refuge-art__petal--c"></div><span>respirer<br>est déjà<br>un début.</span></div></section>' +
      '<div class="refuge-ticker" aria-label="Nos principes"><span>À votre rythme</span><span>Sans jugement</span><span>Sans pression commerciale</span><span>Vos limites comptent</span></div>' +
      '<section class="refuge-section refuge-editorial"><div><span class="refuge-kicker">Ce qui a sa place ici</span><h2>Tout n’a pas besoin d’être réglé aujourd’hui.</h2></div><p>Fatigue, perte de confiance, inquiétude après un échange difficile, question sur un contrat : ce sont des sujets légitimes. Sève veut rendre la première démarche plus simple, sans vous demander de raconter toute votre histoire d’un seul coup.</p></section>' +
      '<section class="refuge-section"><span class="refuge-kicker">Choisissez votre point de départ</span><h2>De quoi auriez-vous besoin ?</h2>' + topicCards() +
      '<p class="refuge-privacy">Ces sujets ouvrent votre fil privé avec l’administration Sève après connexion. Ne transmettez pas de pièce d’identité dans le chat.</p></section>' +
      '<section class="refuge-section refuge-steps"><div class="refuge-steps__intro"><span class="refuge-kicker">Une expérience plus légère</span><h2>Trois gestes. Pas un labyrinthe.</h2><p>Une interface pensée pour aller à l’essentiel, même lorsque vous n’avez pas l’énergie de chercher longtemps.</p></div>' +
      '<div class="refuge-steps__grid"><article><span>01</span><h3>Choisir un sujet</h3><p>Fatigue, confiance, questions ou droits : commencez là où vous êtes, sans devoir trouver les mots parfaits.</p></article>' +
      '<article><span>02</span><h3>Écrire à votre rythme</h3><p>Un fil privé avec l’administration Sève conserve vos échanges entre vos appareils. Ne partagez pas de documents d’identité dans le chat.</p></article>' +
      '<article><span>03</span><h3>Faire une pause</h3><p>Revenir plus tard, ralentir, ou juste lire les ressources. Prendre du recul reste une option, jamais une obligation.</p></article></div></section>' +
      '<section class="refuge-section refuge-split"><div class="refuge-split__color"><span class="refuge-kicker">Votre espace</span><h2>Un tableau de bord qui ne vous en demande pas plus.</h2><p>Les actions importantes restent visibles : écrire, respirer, retrouver votre fil et choisir la suite. Le reste peut attendre.</p><a href="#/signup">Ouvrir mon espace →</a></div>' +
      '<div class="refuge-split__list"><p><b>💌 Un fil lisible</b><span>Pas de menu compliqué pour retrouver vos échanges.</span></p><p><b>🌿 Une vraie place pour la pause</b><span>Un accès rapide au coin détente, sans injonction au résultat.</span></p><p><b>🧭 Des repères clairs</b><span>Des ressources externes identifiées pour les questions urgentes ou juridiques.</span></p></div></section>' +
      '<section class="refuge-section refuge-safety"><span class="refuge-kicker">Clarté et sécurité</span><h2>Ce que nous ne voulons pas vous faire croire.</h2><div class="refuge-safety__grid">' +
      '<p><b>Pas un service d’urgence</b> En danger immédiat : 17 ou 112. En détresse psychologique en France : <a href="https://3114.fr/" target="_blank" rel="noopener noreferrer">3114 ↗</a>.</p>' +
      '<p><b>Un fil reçu par Sève</b> Le fil privé du compte serveur est reçu par l’administration Sève. Les anciens messages de démonstration, uniquement locaux, ne sont pas transmis.</p>' +
      '<p><b>Pas un avis juridique</b> Pour une situation personnelle, contactez un professionnel ou consultez <a href="https://www.service-public.gouv.fr/particuliers/vosdroits/F20706" target="_blank" rel="noopener noreferrer">Service-Public ↗</a>.</p></div></section>' +
      '<section class="refuge-section refuge-faq"><span class="refuge-kicker">Questions fréquentes</span><h2>Les choses importantes, sans petites lignes.</h2>' +
      '<details><summary>Est-ce que Sève est ouvert à de nouvelles inscriptions ?</summary><p>Oui, créez un compte personnel gratuit après avoir confirmé votre majorité.</p></details>' +
      '<details><summary>Est-ce qu’une équipe lit déjà mes messages ?</summary><p>Les nouveaux messages du fil privé sont reçus par l’administration Sève. Les anciens messages de démonstration restent seulement sur votre appareil.</p></details>' +
      '<details><summary>Puis-je envoyer des images explicites ?</summary><p>Chaque PNG exige un contrôle réel de majorité enregistré par l’administration et un accord avant envoi. Il reste privé jusqu’à sa validation manuelle ; un contenu illégal ou non consenti est interdit.</p></details>' +
      '<details><summary>Que deviennent mes anciens comptes ?</summary><p>Une bascule d’apparence ne les efface pas. Les données restées dans votre navigateur ne sont pas synchronisées automatiquement avec le serveur.</p></details></section>' +
      '<section class="refuge-end"><span class="refuge-kicker">La suite, ensemble</span><h2>Vous n’avez pas à tout porter en silence.</h2><p>Vous pouvez commencer par un message ou simplement explorer les ressources, à votre rythme.</p><div><a class="refuge-cta" href="#/signup">Créer mon espace →</a><a href="#/cgu">Lire le cadre du service</a></div></section>';
  }};
  SEVE.views.refugeDashboard = { title: 'Mon espace', render() {
    const vrai = String((store.currentUser() || {}).id || '').startsWith('rf_');
    return '<div class="refuge-workspace"><section class="refuge-workspace__welcome"><div><span class="refuge-kicker">Mon espace · aujourd’hui</span>' +
      '<h1>Bonjour ' + esc(nom()) + '<span class="refuge-dot">.</span></h1><p>Vous pouvez commencer petit. Un geste suffit, ou aucun si vous avez besoin de repos.</p>' +
      '<div class="refuge-workspace__actions"><a class="refuge-cta" href="#/app/team">💬 Ouvrir ma conversation</a><a class="refuge-cta refuge-cta--light" href="#/app/resources">📚 Mes ressources</a></div></div>' +
      '<div class="refuge-workspace__flower" aria-hidden="true">✿</div></section>' +
      '<div class="refuge-workspace__status"><span>● ' + (SEVE.lancement.ouvert ? 'Compte et messagerie en ligne' : 'Service en préparation') + '</span><span>' +
      (vrai ? 'Identité de connexion sur le serveur' : 'Profil d’essai local') + '</span><span>Pas de paiement demandé</span></div>' +
      '<section class="refuge-workspace__grid"><a class="refuge-workspace__tile refuge-workspace__tile--pink" href="#/app/team"><span>💌</span><small>01 · DIRE</small><h2>Qu’est-ce qui vous pèse ?</h2><p>Un fil simple pour écrire quand vous êtes prête. Emojis disponibles. Images suspendues jusqu’à vérification.</p><b>Ouvrir le fil →</b></a>' +
      '<a class="refuge-workspace__tile refuge-workspace__tile--yellow" href="#/app/resources"><span>📚</span><small>02 · S’ORIENTER</small><h2>Des ressources fiables.</h2><p>Retrouvez des contacts utiles, des informations officielles et quelques repères pratiques.</p><b>Voir mes ressources →</b></a>' +
      '<a class="refuge-workspace__tile refuge-workspace__tile--mint" href="#/"><span>🧭</span><small>03 · EXPLORER</small><h2>Retrouver des repères.</h2><p>Explorez les sujets abordés par Sève et le cadre de l’espace refuge.</p><b>Voir l’accueil →</b></a></section>' +
      '<section class="refuge-workspace__lower"><div><span class="refuge-kicker">À votre rythme</span><h2>Vous n’avez pas besoin d’avoir toutes les réponses.</h2><p>Choisissez un sujet pour mettre des mots sur ce que vous vivez, ou revenez plus tard.</p></div>' + topicCards() + '</section>' +
      '<p class="refuge-privacy">' + (SEVE.lancement.ouvert ? 'Vos messages envoyés dans le nouveau fil seront stockés sur le serveur et visibles par une personne administratrice habilitée.' : 'Préouverture : aucun nouveau message n’est transmis. Les anciens fils de la maquette restent sur cet appareil.') +
      ' Les données de profil historiques ne sont pas automatiquement synchronisées entre appareils.</p></div>';
  }};
  SEVE.views.refugeResources = { title: 'Mes ressources', render() {
    const fiches = [
      {
        id: 'ressource-identite', tone: 'rose', number: '01', category: 'IDENTITÉ & COMPTES',
        title: 'Protéger mon identité en ligne',
        intro: 'Un pseudonyme seul ne garantit pas l’anonymat : plusieurs petits indices peuvent se recouper.',
        body: '<ul><li>Séparez autant que possible vos comptes professionnels et personnels : adresse dédiée, alias et paramètres de visibilité distincts.</li><li>Ne donnez que les informations nécessaires à l’inscription ; évitez les coordonnées, lieux et habitudes qui révèlent où vous êtes.</li><li>Utilisez un mot de passe unique et robuste par compte, un gestionnaire si vous en avez un, et activez la double authentification.</li><li>Vérifiez périodiquement les sessions connectées, les applications tierces autorisées et les options de géolocalisation.</li><li>Avant une publication, regardez l’arrière-plan, les reflets, les badges, les documents, les fenêtres et les indices de lieu ou d’horaire.</li></ul>',
        sources: [['CNIL · protéger son identité', 'https://www.cnil.fr/fr/4-reflexes-pour-mieux-proteger-votre-identite-en-ligne'], ['CNIL · recoupement d’informations', 'https://www.cnil.fr/fr/recoupement-dinformations-en-ligne-ce-que-vous-publiez-peut-devoiler-votre-vie-privee'], ['Cybermalveillance · mots de passe', 'https://www.cybermalveillance.gouv.fr/tous-nos-contenus/bonnes-pratiques/mots-de-passe']]
      },
      {
        id: 'ressource-chantage', tone: 'peach', number: '02', category: 'CHANTAGE & CYBERMALVEILLANCE',
        title: 'Que faire face à une sextorsion ?',
        intro: 'Si quelqu’un menace de diffuser une image ou demande de l’argent ou d’autres contenus, vous n’avez pas à gérer cela seule.',
        body: '<ol><li>Ne transmettez pas d’autres contenus et ne payez pas de rançon. La fiche officielle recommande de ne plus répondre, puis de bloquer le compte.</li><li>Verrouillez vos comptes et limitez la visibilité de vos listes de contacts et publications.</li><li>Conservez les preuves utiles : messages, identifiant du compte, dates et liens. Évitez de repartager les images intimes.</li><li>Signalez le compte et le contenu à la plateforme. Vous pouvez aussi demander conseil à Cybermalveillance, déposer plainte ou vous faire accompagner.</li><li>Si le contenu est déjà publié, demandez son retrait au site concerné ; la fiche officielle explique aussi les démarches de signalement et de déréférencement.</li></ol>',
        sources: [['Cybermalveillance · que faire en cas de sextorsion ?', 'https://www.cybermalveillance.gouv.fr/tous-nos-contenus/fiches-reflexes/sextorsion'], ['Cybermalveillance · usurpation d’identité', 'https://www.cybermalveillance.gouv.fr/tous-nos-contenus/fiches-reflexes/usurpation-identite-que-faire'], ['France Victimes · aide aux victimes', 'https://www.france-victimes.fr/']]
      },
      {
        id: 'ressource-image', tone: 'lilac', number: '03', category: 'IMAGE, CONSENTEMENT & RETRAIT',
        title: 'Garder la maîtrise de son image',
        intro: 'Avant une collaboration, précise ce que tu autorises : une autorisation de prise de vue ne répond pas à toutes les questions de diffusion.',
        body: '<ul><li>Pour une image où vous êtes reconnaissable, clarifiez par écrit le support, l’objectif et la durée d’utilisation.</li><li>Précisez les usages autorisés, les éventuelles modifications, les personnes qui peuvent y accéder et si une réutilisation est prévue.</li><li>Un usage différent de celui convenu peut nécessiter un nouvel accord. Gardez une copie des échanges et de la version signée.</li><li>Si une image est diffusée sans votre accord, Service-Public indique les démarches possibles : demander le retrait à l’auteur, contacter le site, et selon la situation saisir les autorités ou un juge.</li><li>Ne republiez pas l’image pour prouver le problème. Gardez plutôt le lien, la date et les éléments de contexte de façon sûre.</li></ul>',
        sources: [['Service-Public · droit à l’image et vie privée', 'https://www.service-public.gouv.fr/particuliers/vosdroits/F32103'], ['CNIL · demander le retrait de son image en ligne', 'https://www.cnil.fr/fr/demander-le-retrait-de-votre-image-en-ligne']]
      },
      {
        id: 'ressource-contrat', tone: 'cream', number: '04', category: 'COLLABORATION & CONTRAT',
        title: 'Les points à clarifier avant de dire oui',
        intro: 'Une liste de vérification pratique — pas un avis juridique — pour poser les bonnes questions avant de commencer.',
        body: '<ul><li><b>Mission :</b> quels contenus ou services sont attendus, et qu’est-ce qui n’est pas compris ?</li><li><b>Rémunération :</b> montant, devise, échéance, commissions et frais éventuels.</li><li><b>Planning :</b> dates de livraison, délais de réponse, retards et procédure en cas d’imprévu.</li><li><b>Droits d’usage :</b> plateformes, durée, territoire, publicité payante, exclusivité, retouches et réutilisations.</li><li><b>Fin de collaboration :</b> préavis, résiliation, paiements en attente, retrait des accès et suppression ou conservation des fichiers.</li><li><b>Trace écrite :</b> demandez que les changements importants soient confirmés par écrit ; ne signez pas si une clause reste incomprise.</li></ul>',
        sources: [['Service-Public · informations officielles', 'https://www.service-public.gouv.fr/'], ['Point-Justice · trouver une aide juridique', 'https://www.justice.fr/']]
      },
      {
        id: 'ressource-message', tone: 'rose', number: '05', category: 'PRÉPARER UN MESSAGE',
        title: 'Mettre mes idées au clair',
        intro: 'Vous pouvez écrire quelques notes avant d’ouvrir votre fil. Vous n’avez pas besoin de tout raconter d’un coup.',
        body: '<ol><li><b>Ce qui se passe :</b> quelques faits, avec les dates utiles si vous les avez.</li><li><b>Ce dont j’aurais besoin :</b> être écoutée, trouver une prochaine étape, ou obtenir une ressource.</li><li><b>Ce que je préfère éviter :</b> un appel, certains sujets, ou le partage de détails personnels.</li><li><b>Ce que je peux partager sans risque :</b> gardez les pièces d’identité, mots de passe, coordonnées bancaires et contenus intimes hors du chat.</li></ol><p>Vous pouvez commencer par une phrase courte et compléter plus tard.</p>',
        sources: []
      },
      {
        id: 'ressource-soutien', tone: 'peach', number: '06', category: 'ÉCOUTE & URGENCE · FRANCE',
        title: 'Contacter une aide extérieure',
        intro: 'Si vous êtes en danger ou avez besoin d’une écoute spécialisée, ces services sont distincts de Sève.',
        body: '<ul><li><b>Danger immédiat :</b> appelez le 17 ou le 112. Si vous ne pouvez pas parler ou entendre, le 114 est accessible par SMS.</li><li><b>Détresse ou pensées suicidaires :</b> le 3114 est gratuit, confidentiel et accessible 24 h/24, 7 j/7 en France.</li><li><b>Besoin d’aide en tant que victime :</b> France Victimes répond au 116 006, appel gratuit, 7 jours sur 7 de 9 h à 19 h.</li><li><b>Cyberharcèlement ou violence numérique :</b> la fiche Cybermalveillance sur la sextorsion présente aussi le 3018 et les démarches de retrait.</li></ul>',
        sources: [['Urgence · Police secours 17 / 112', 'https://lannuaire.service-public.gouv.fr/centres-contact/R1201'], ['3114 · prévention du suicide', 'https://3114.fr/'], ['Cybermalveillance · sextorsion et aides', 'https://www.cybermalveillance.gouv.fr/tous-nos-contenus/fiches-reflexes/sextorsion']]
      }
    ];
    return '<section class="refuge-resources-page">' +
      head('Bibliothèque refuge', 'Des ressources concrètes, à votre rythme.', 'Des repères détaillés pour protéger vos comptes, clarifier une collaboration et trouver de l’aide. Vous pouvez ouvrir seulement les fiches qui vous sont utiles.') +
      '<nav class="refuge-resource-index" aria-label="Sommaire des ressources">' + fiches.map((f) => '<a href="#' + f.id + '">' + f.number + ' · ' + f.category + '</a>').join('') + '</nav>' +
      '<div class="refuge-resource-list">' + fiches.map((f) =>
        '<article class="refuge-resource-card refuge-resource-card--' + f.tone + '" id="' + f.id + '"><span class="refuge-resource-card__mark">' + f.number + '</span><div><small>' + f.category + '</small><h2>' + f.title + '</h2><p>' + f.intro + '</p><details><summary>Lire la fiche complète</summary>' + f.body + '</details>' +
        (f.sources.length ? '<div class="refuge-resource-sources"><b>Sources &amp; démarches</b>' + f.sources.map((l) => '<a href="' + l[1] + '" target="_blank" rel="noopener noreferrer">' + l[0] + ' ↗</a>').join('') + '</div>' : '') +
        (f.id === 'ressource-message' ? '<a class="refuge-resource-inline" href="#/app/team">Écrire à l’équipe Sève →</a>' : '') + '</div></article>').join('') + '</div>' +
      '<p class="refuge-resource-note">Ces fiches sont des repères généraux, pas des conseils médicaux ou juridiques. Les démarches et numéros indiqués concernent la France ; vérifiez les informations sur les sites officiels si votre situation ou votre pays est différent.</p>' +
      '<div class="refuge-resource-actions"><a class="refuge-cta" href="#/app/team">💬 Ouvrir ma conversation</a><a class="refuge-cta refuge-cta--light" href="#/app">Retour à mon espace</a></div></section>';
  }};

  SEVE.views.refugePause = { title: 'Ma pause', render() {
    if (!String((store.currentUser() || {}).id || '').startsWith('rf_')) return '<section class="refuge-auth"><h1>Pause réservée aux comptes personnels</h1><p>Cette fonction n’est pas disponible dans le profil d’essai.</p><a href="#/app">Retour à mon espace</a></section>';
    const c = store.care();
    return head('Votre rythme vous appartient', 'Faire une pause, c’est permis.', 'Vous pouvez disparaître de la recherche et garder vos conversations. Personne n’a besoin de savoir pourquoi.') +
      '<div class="refuge-feature refuge-feature--yellow refuge-narrow"><span>🌤️</span><h2>' + (c.pause ? 'Vous êtes en pause.' : 'Et si vous ralentissiez ?') + '</h2>' +
      '<p>' + (c.pause ? 'Votre profil ne remonte plus dans la recherche. Votre fil de discussion reste ouvert.' : 'Un clic suffit. Vos informations ne seront pas supprimées.') + '</p>' +
      ui.btn({ label: c.pause ? 'Reprendre mon activité' : 'Mettre mon profil en pause', variant: 'primary', act: 'care-toggle', data: { key: 'pause' }, icon: c.pause ? 'play' : 'pause' }) +
      '</div><p class="refuge-privacy"><a href="#/app/team">Besoin d’en parler ? Écrivez dans votre espace →</a></p>';
  }};
  function renduMessages(messages, equipe) {
    if (!messages.length) return '<div class="refuge-chat__empty"><span aria-hidden="true">💬</span><b>Votre fil commence ici.</b><p>Vous pouvez écrire quelques mots quand vous le souhaitez. Rien n’est envoyé avant d’appuyer sur « Envoyer ».</p></div>';
    return messages.map((m) => {
      const own = ((m.auteur === 'equipe') === !!equipe);
      const auteur = m.auteur === 'equipe' ? (equipe ? 'Équipe Sève' : 'Équipe Sève') : (equipe ? 'Créatrice' : 'Vous');
      const date = String(m.cree_le || '');
      const heure = date.slice(0, 16).replace('T', ' · ');
      return '<article class="refuge-message ' + (own ? 'refuge-message--mine' : 'refuge-message--team') + '">' +
        '<div class="refuge-message__meta"><b>' + auteur + '</b>' + (heure ? '<time datetime="' + esc(date) + '">' + esc(heure) + '</time>' : '') + '</div>' +
        '<div class="refuge-message__bubble">' + esc(String(m.texte || '')) + '</div></article>';
    }).join('');
  }
  function afficherImages(images, admin) {
    return (images || []).map((item) => {
      const id = String(item.id || '');
      if (!/^[a-f0-9]{32}$/.test(id)) return '';
      const nom = admin ? '<b>' + esc(item.nom || 'Compte') + '</b> ' : '';
      return '<div class="refuge-image-card">' + nom +
        (item.statut === 'approuvee' || admin ? '<img loading="lazy" alt="PNG partagé dans la conversation" src="api/refuge/chat/image?id=' + id + '">' : '') +
        '<span>' + (item.statut === 'attente' ? 'PNG en attente : seul l’administrateur peut consulter le fichier avant approbation.' :
          item.statut === 'approuvee' ? 'PNG validé' : 'PNG retiré') + '</span></div>';
    }).join('');
  }
  function chatInterface(admin, id) {
    const autorise = !!SEVE.lancement.ouvert && (admin ? SEVE.refuge.adminSeve() : String((store.currentUser() || {}).id || '').startsWith('rf_'));
    const titre = admin ? 'Conversation avec une créatrice' : 'Votre fil avec l’équipe Sève';
    const resume = autorise
      ? 'Votre message part uniquement lorsque vous appuyez sur Envoyer.'
      : 'Messagerie en préparation : aucun message n’est transmis depuis cette preview.';
    return '<section class="refuge-chat refuge-chat--redesigned">' +
      '<header class="refuge-chat__header"><span class="refuge-chat__avatar" aria-hidden="true">' + (admin ? '🌿' : '💬') + '</span>' +
      '<div class="refuge-chat__heading"><small>' + (admin ? 'ESPACE ÉQUIPE · FIL PRIVÉ' : 'VOTRE ESPACE PRIVÉ') + '</small><h2>' + titre + '</h2><p>' + resume + '</p></div>' +
      '<span class="refuge-chat__status ' + (autorise ? 'is-open' : 'is-pending') + '"><i></i>' + (autorise ? 'Ouvert' : 'En préparation') + '</span></header>' +
      '<div class="refuge-chat__notice"><span aria-hidden="true">♡</span><p><b>À votre rythme.</b> Vous pouvez écrire, faire une pause ou revenir plus tard. Évitez d’envoyer des mots de passe ou des documents d’identité.</p></div>' +
      '<div class="refuge-chat__history" id="refuge-history" aria-live="polite" aria-label="Historique de la conversation">' +
      (autorise ? '<div class="refuge-chat__loading"><span class="refuge-chat__loader" aria-hidden="true"></span><p>Ouverture de votre fil…</p></div>' : '<div class="refuge-chat__empty"><span aria-hidden="true">🌿</span><b>Le fil n’est pas encore ouvert.</b><p>Aucun message ne sera envoyé pendant la préparation du service.</p></div>') + '</div>' +
      '<div class="refuge-compose"><div class="refuge-compose__head"><label for="refuge-message">Votre message</label><span>1 à 4 000 caractères</span></div>' +
      '<textarea id="refuge-message" class="textarea" rows="4" maxlength="4000" ' + (autorise ? '' : 'disabled ') + 'placeholder="Écrivez simplement ce que vous souhaitez dire…"></textarea>' +
      '<div class="refuge-compose__toolbar"><div class="refuge-compose__tools" aria-label="Emojis rapides">' + ['💗','🌿','✨','💬','🙏','😊'].map((e) =>
        '<button type="button" data-act="refuge-emoji" data-emoji="' + e + '" aria-label="Insérer ' + e + '" ' + (autorise ? '' : 'disabled') + '>' + e + '</button>').join('') + '</div>' +
      '<button type="button" class="refuge-compose__png" data-act="refuge-png" title="PNG soumis à vérification et modération" ' + (autorise ? '' : 'disabled') + '>＋ Joindre un PNG</button><input id="refuge-png-input" type="file" accept="image/png,.png" hidden></div>' +
      '<div id="refuge-images" class="refuge-chat__images" aria-live="polite"></div>' +
      '<details class="refuge-chat__image-rules"><summary>À savoir avant de joindre un PNG</summary><p>Les images restent privées jusqu’à vérification et modération. Ne joignez que des contenus que vous avez le droit de partager et qui respectent le consentement de chaque personne représentée. N’envoyez jamais de pièce d’identité ici.</p></details>' +
      '<div class="refuge-chat__send"><span>Vous gardez le choix : l’envoi ne se fait qu’en appuyant sur le bouton.</span>' +
      ui.btn({ label: 'Envoyer', variant: 'primary', act: 'refuge-send', icon: 'send', disabled: !autorise }) + '</div></div></section>';
  }
  SEVE.views.refugeTalk = { title: 'Conversation', render() {
    const ouvert = !!SEVE.lancement.ouvert;
    return '<section class="refuge-talk-page"><header class="refuge-talk-heading">' +
      '<div><span class="refuge-kicker">UN ESPACE POUR ÉCRIRE</span><h1>Parler, à votre rythme.</h1><p>Un fil simple avec l’équipe Sève. Vous pouvez dire ce qui vous préoccupe, poser une question ou demander un repère.</p></div>' +
      '<div class="refuge-talk-deadline"><span class="refuge-talk-deadline__icon">♡</span><div><b>' + (ouvert ? 'Réponse sous 24 h ouvrées maximum' : 'Messagerie en préparation') + '</b><small>' + (ouvert ? 'Aucune réponse automatique.' : 'Aucun message ne sera transmis.') + '</small></div></div>' +
      '</header><div class="refuge-talk-layout"><div class="refuge-talk-main">' + chatInterface(false, '') + '</div>' +
      '<aside class="refuge-talk-aside"><article class="refuge-talk-tip"><span>01 · CONFIDENTIALITÉ</span><h2>Partagez seulement l’essentiel.</h2><p>Gardez les mots de passe, pièces d’identité et coordonnées bancaires hors du chat.</p></article>' +
      '<article class="refuge-talk-tip refuge-talk-tip--peach"><span>02 · À VOTRE RYTHME</span><h2>Une phrase suffit pour commencer.</h2><p>Vous pouvez compléter votre message plus tard ou demander une ressource utile.</p><a href="#/app/resources">Ouvrir Mes ressources →</a></article>' +
      '<article class="refuge-talk-tip refuge-talk-tip--urgent"><span>03 · BESOIN IMMÉDIAT ?</span><h2>Sève n’est pas un service d’urgence.</h2><p>En danger immédiat en France : 17 ou 112. Pour une écoute en prévention du suicide : 3114, gratuit 24 h/24 et 7 j/7.</p><a href="https://3114.fr/" target="_blank" rel="noopener noreferrer">Informations sur le 3114 ↗</a></article></aside></div></section>';
  }, mount() {
    if (!SEVE.lancement.ouvert || !String((store.currentUser() || {}).id || '').startsWith('rf_')) return;
    SEVE.refuge.chatLire().then((r) => { const box=document.getElementById('refuge-history');
      if (box) box.innerHTML = r.ok ? renduMessages(r.messages || [], false) : '<p>' + esc(r.erreur || 'Fil indisponible.') + '</p>';
    });
    SEVE.refuge.imagesListe().then((r) => { const box=document.getElementById('refuge-images');
      if (box && r.ok) box.innerHTML = afficherImages(r.images,false);
    });
    const input=document.getElementById('refuge-png-input');
    if(input) input.addEventListener('change',() => {
      const file=input.files && input.files[0]; if(!file) return; input.value='';
      if(file.type !== 'image/png' || file.size > 4*1024*1024){ui.toast('PNG de 4 Mo maximum uniquement.','err');return;}
      ui.confirm({title:'Autorisez-vous cet envoi de PNG ?',
        text:'Je confirme être majeure, avoir le droit de partager cette image et avoir recueilli le consentement de chaque personne représentée. Je comprends qu’elle sera examinée avant toute visibilité.',
        okLabel:'Oui, envoyer pour modération',cancelLabel:'Non, ne pas envoyer'
      }).then((oui)=>{if(!oui)return; SEVE.refuge.envoyerPNG(file).then((r)=>{
        ui.toast(r.ok?'PNG transmis pour modération ; il n’est pas encore visible.':(r.erreur||'Envoi refusé.'),r.ok?'ok':'err');
        if(r.ok)SEVE.refuge.imagesListe().then((res)=>{const box=document.getElementById('refuge-images');if(box&&res.ok)box.innerHTML=afficherImages(res.images,false);});
      });});
    });
  }};
  SEVE.views.adminConnexion = { title: 'Administration Sève', render() {
    return '<section class="refuge-auth"><div class="refuge-head"><span class="refuge-kicker">Accès privé</span><h1>Administration Sève.</h1><p>Mot de passe vérifié côté serveur. Aucun accès avec le compte de démonstration.</p></div>' +
      '<form id="seve-admin-form"><label>Identifiant<input class="input" name="identifiant" required autocomplete="username" value="admin"></label>' +
      '<label>Mot de passe<input class="input" name="mot_de_passe" type="password" required autocomplete="current-password"></label>' +
      '<button class="refuge-cta" type="submit">Se connecter</button></form><p>Configurez d’abord l’empreinte dans <code>seve/config-local-seve.php</code> sur l’hébergement.</p></section>';
  }, mount(ctx) {
    const form=ctx.root.querySelector('#seve-admin-form');
    form.addEventListener('submit',(e)=>{e.preventDefault();const d=Object.fromEntries(new FormData(form));const btn=form.querySelector('button');btn.disabled=true;
      SEVE.refuge.adminLogin(d.identifiant,d.mot_de_passe).then((r)=>{btn.disabled=false;
        if(!r.ok){ui.toast(r.erreur||'Connexion refusée.','err');return;}SEVE.router.navigate('/admin');
      });
    });
  }};
  SEVE.views.adminMajorite = { title: 'Contrôle de majorité', render() {
    return '<section class="refuge-admin-chat"><a href="#/admin">← Administration</a><h1>Contrôles de majorité</h1>' +
      '<p>Examinez réellement une pièce d’identité hors de cette interface. Ne téléversez ni ne copiez la pièce dans Sève. Enregistrez une référence interne de contrôle seulement après examen.</p>' +
      '<p>Une déclaration d’âge par la personne ne constitue pas une vérification. Les PNG restent bloqués tant que consentement et modération ne sont pas prêts.</p><div id="admin-age-list">Chargement…</div></section>';
  }, mount() {
    if(!SEVE.refuge.adminSeve())return;
    SEVE.refuge.adminComptes().then((r)=>{const box=document.getElementById('admin-age-list');if(!box)return;
      box.innerHTML=r.ok?(r.comptes||[]).map((u)=>'<div class="refuge-thread"><div><b>'+esc(u.nom)+'</b><span>'+esc(u.email)+' · '+(u.age_verifie_le?'Majorité contrôlée':'À contrôler')+'</span></div>'+
        (u.age_verifie_le?'':'<button type="button" class="btn btn--outline" data-act="admin-verifier-age" data-id="'+esc(u.id)+'">Enregistrer un contrôle réel</button>')+'</div>').join(''):'<p>'+esc(r.erreur||'Comptes indisponibles.')+'</p>';
    });
  }};
  SEVE.act('admin-verifier-age',(el)=>{
    if(!SEVE.refuge.adminSeve())return;
    const ref=prompt('Référence du contrôle réel de la pièce (sans numéro de pièce ni photo) :');
    if(!ref)return;
    if(!confirm('Confirmez-vous avoir personnellement examiné une preuve de majorité valable pour cette personne ?'))return;
    SEVE.refuge.verifierAge(el.getAttribute('data-id'),ref).then((r)=>{
      ui.toast(r.ok?'Contrôle enregistré. Les images restent bloquées.':(r.erreur||'Refusé.'),r.ok?'ok':'err');
      if(r.ok)SEVE.router.refresh();
    });
  });
  SEVE.views.adminImages = { title: 'Images à modérer', render() {
    return '<section class="refuge-admin-chat"><a href="#/admin">← Administration</a><h1>PNG à contrôler</h1>' +
      '<p>Les images ne sont visibles aux autres utilisateurs qu’après validation. Retirer supprime le fichier ; ne validez jamais un contenu illicite, non consenti ou impliquant un mineur.</p>' +
      '<div id="refuge-images-admin">Chargement…</div></section>';
  }, mount() {
    if(!SEVE.refuge.adminSeve())return;
    SEVE.refuge.imagesListe().then((r)=>{const box=document.getElementById('refuge-images-admin');if(!box)return;
      box.innerHTML=r.ok ? ((r.images||[]).length ? (r.images||[]).map((item)=>{
        const id=String(item.id||'');if(!/^[a-f0-9]{32}$/.test(id))return '';
        return '<div class="refuge-image-card"><b>'+esc(item.nom)+' · '+esc(item.email)+'</b><img loading="lazy" src="api/refuge/chat/image?id='+id+'" alt="PNG en attente de modération">' +
          '<div>'+(item.statut==='attente'?'<button class="btn btn--outline" data-act="refuge-image-decision" data-id="'+id+'" data-decision="approuver">Approuver</button> ':'') +
          '<button class="btn btn--danger" data-act="refuge-image-decision" data-id="'+id+'" data-decision="retirer">Retirer le fichier</button></div></div>';
      }).join('') : '<p>Aucun PNG en attente.</p>') : '<p>'+esc(r.erreur||'File indisponible.')+'</p>';
    });
  }};
  SEVE.act('refuge-image-decision',(el)=>{
    const decision=el.getAttribute('data-decision');
    ui.confirm({title:decision==='retirer'?'Retirer définitivement ce PNG ?':'Approuver ce PNG ?',
      text:'Confirmez avoir examiné la majorité, le consentement et la légalité du contenu.',okLabel:decision==='retirer'?'Retirer':'Approuver',cancelLabel:'Annuler',danger:decision==='retirer'}).then((ok)=>{
        if(!ok)return;SEVE.refuge.modererImage(el.getAttribute('data-id'),decision).then((r)=>{
          ui.toast(r.ok?'Décision enregistrée.':(r.erreur||'Refusé.'),r.ok?'ok':'err');if(r.ok)SEVE.router.refresh();
        });
      });
  });
  SEVE.views.adminRefuge = { title: 'Conversations refuge', render(ctx) {
    if (!SEVE.refuge.adminSeve()) return '<section class="refuge-admin-chat"><h1>Accès serveur réservé</h1><p>Connectez-vous avec votre compte administrateur Sève pour voir les véritables conversations. La démo admin ne les affiche pas.</p></section>';
    const id = String(ctx.query.id || '');
    return '<section class="refuge-admin-chat"><a href="#/admin">← Administration</a><h1>Conversations refuge</h1><p>Aucun message fictif dans cet espace. Réponses écrites uniquement par une personne habilitée.</p>' +
      (id ? '<a href="#/admin/refuge">← Tous les fils</a>' + chatInterface(true, id) : '<div id="refuge-fils"><p>Chargement des conversations…</p></div>') + '</section>';
  }, mount(ctx) {
    if (!SEVE.refuge.adminSeve() || !SEVE.lancement.ouvert) return;
    const id = String(ctx.query.id || '');
    if (id) SEVE.refuge.chatLire(id).then((r) => { const box=document.getElementById('refuge-history');
      if (box) box.innerHTML = r.ok ? renduMessages(r.messages || [], true) : '<p>' + esc(r.erreur || 'Fil inaccessible.') + '</p>';
    });
    else SEVE.refuge.chatFils().then((r) => { const box=document.getElementById('refuge-fils');
      if (box) box.innerHTML = r.ok ? ((r.fils || []).length ? r.fils.map((f) =>
        '<a class="refuge-thread" href="#/admin/refuge?id=' + encodeURIComponent(f.id) + '"><b>' + esc(f.nom) + '</b><span>' + esc(f.email) + ' · ' + Number(f.messages) + ' messages</span></a>').join('') : '<p>Aucune conversation serveur.</p>') : '<p>' + esc(r.erreur || 'Service indisponible.') + '</p>';
    });
  }};
  function authForm(inscrire) {
    return '<section class="refuge-auth">' + head(inscrire ? 'Un endroit à vous' : 'Heureuse de vous revoir', inscrire ? 'Créer mon espace.' : 'Revenir à mon espace.',
      'Ce compte reste le même si l’apparence du site change.') +
      '<form id="refuge-form"><label>Votre adresse e-mail<input class="input" name="email" type="email" required autocomplete="email"></label>' +
      (inscrire ? '<label>Comment vous appeler ?<input class="input" name="name" required maxlength="90" autocomplete="name"></label>' : '') +
      '<label>Mot de passe<input class="input" name="password" type="password" required minlength="10" autocomplete="' + (inscrire ? 'new-password' : 'current-password') + '"></label>' +
      (inscrire ? '<p class="refuge-privacy">Votre compte est conservé sur le serveur et accessible depuis vos appareils. L’adresse e-mail n’est pas vérifiée. Les nouveaux messages du fil privé sont reçus par l’administration Sève ; les anciens échanges de démonstration restent locaux.</p>' : '') +
      '<button class="refuge-cta refuge-cta--large" type="submit">' + (inscrire ? 'Créer mon espace gratuit' : 'Se connecter') + '</button></form>' +
      '<p>' + (inscrire ? 'Déjà inscrite ? <a href="#/login">Se connecter</a>' : 'Nouvelle ici ? <a href="#/signup">Créer un espace gratuit</a>') + '</p>' +
      '<div class="refuge-auth-choix"><b>Entrer plus vite</b><button type="button" class="refuge-cta refuge-cta--light" data-act="demo-login" data-role="creator">Essayer comme créatrice · démo</button>' +
      '<a href="#/admin/connexion">Administratrice ? Connexion Sève sécurisée →</a></div></section>';
  }
  function bindAuth(ctx, inscrire) {
    const f = ctx.root.querySelector('#refuge-form');
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const v = Object.fromEntries(new FormData(f));
      const bouton = f.querySelector('button[type="submit"]');
      bouton.disabled = true;
      const confirmerAge = inscrire ? ui.confirm({
        title: 'Avez-vous au moins 18 ans ?',
        text: 'Sève est réservé aux personnes majeures. Confirmez-vous avoir 18 ans révolus ?',
        detail: 'Cette déclaration ne remplace pas une vérification de majorité. Aucune inscription n’est envoyée si vous refusez.',
        okLabel: 'Oui, j’ai au moins 18 ans',
        cancelLabel: 'Non / annuler'
      }) : Promise.resolve(true);
      confirmerAge.then((majeure) => {
        if (!majeure) {
          bouton.disabled = false;
          ui.toast('Inscription annulée : aucun compte n’a été créé.', 'info');
          return;
        }
        SEVE.refuge.connecter({ name: inscrire ? v.name.trim() : '', email: v.email,
          password: v.password, majeure_declaree: !!inscrire }, inscrire).then((r) => {
          bouton.disabled = false;
          if (!r.ok) { ui.toast(r.erreur || 'Connexion impossible. Réessayez.', 'err'); return; }
          SEVE.router.navigate('/app');
        }).catch(() => { bouton.disabled = false; ui.toast('Serveur injoignable. Aucun compte créé.', 'err'); });
      });
    });
  }
  SEVE.views.refugeLogin = { title: 'Connexion', render: () => authForm(false), mount(ctx) { bindAuth(ctx, false); }};
  SEVE.views.refugeSignup = { title: 'Inscription', render: () => authForm(true), mount(ctx) { bindAuth(ctx, true); }};
  SEVE.act('refuge-sortir', () => { SEVE.refuge.sortir().then((r) => {
    if (!r.ok) { ui.toast('Déconnexion serveur impossible. Réessayez.', 'err'); return; }
    store.logout(); SEVE.router.navigate('/');
  }); });
  SEVE.act('refuge-emoji', (el) => {
    const ta = document.getElementById('refuge-message'); if (!ta) return;
    const e = el.getAttribute('data-emoji') || ''; const pos=ta.selectionStart;
    ta.value = ta.value.slice(0,pos) + e + ta.value.slice(ta.selectionEnd);
    ta.focus(); ta.setSelectionRange(pos+e.length,pos+e.length);
  });
  SEVE.act('refuge-png', () => {
    const user=store.currentUser();
    if(!SEVE.lancement.ouvert){ui.toast('Envoi de PNG non ouvert sur ce site.', 'info');return;}
    if(!user || !String(user.id).startsWith('rf_')){ui.toast('Connectez-vous avec un vrai compte refuge.','info');return;}
    if(!user.ageVerified){ui.toast('Demandez d’abord à l’administration Sève de contrôler réellement votre majorité.','info');return;}
    const input=document.getElementById('refuge-png-input');if(input)input.click();
  });
  SEVE.act('refuge-send', () => {
    const ta=document.getElementById('refuge-message'); const texte=(ta && ta.value || '').trim();
    if (!SEVE.lancement.ouvert) { ui.toast('Messagerie fermée : aucun message transmis.', 'info'); return; }
    if (!texte || texte.length > 4000) { ui.toast('Écrivez un message de 1 à 4 000 caractères.', 'info'); return; }
    const admin=location.hash.startsWith('#/admin/refuge');
    const id=admin ? new URLSearchParams(location.hash.split('?')[1] || '').get('id') : '';
    if (admin && !id) return;
    SEVE.refuge.chatEnvoyer(texte,id).then((r) => {
      if (!r.ok) { ui.toast(r.erreur || 'Envoi impossible.', 'err'); return; }
      ta.value=''; const box=document.getElementById('refuge-history');
      if (box) { const empty=box.querySelector('.refuge-chat__empty'); if(empty)empty.remove(); box.insertAdjacentHTML('beforeend',renduMessages([r.message],admin)); box.scrollTop=box.scrollHeight; }
      ui.toast('Message ajouté à la démo locale ; non transmis à Sève.', 'ok');
    });
  });
})();
